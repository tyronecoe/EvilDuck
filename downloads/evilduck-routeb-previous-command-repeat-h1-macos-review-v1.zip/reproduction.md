**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-PREVIOUS-COMMAND-REPEAT-v1`. Application: **1437888 bytes**, SHA-256 `13cec88262afdfa641eb0fb4927fe7903abf2863295344ff316418707ba49b7f`. Firmware source checkpoint: `820a575a45e5a4f644921d663a650110667a6ab2`. These identify the local candidate, not installed device bytes.

The application was clean-built from committed source `820a575a45e5a4f644921d663a650110667a6ab2`. Every selected compile input is bound to its Git blob in build-inputs.json and source-attestation.json. The verifier is from that same checkpoint, with no post-build source or verifier delta. build-receipt.json retains the complete 190-assert release chain, actual static-response linkage and compiled/linked standalone REPEAT proof.

Extract into a new folder and keep EvilDuck **unplugged**. Run only:

```bash
python3 preflight.py --directory .
```

Expect exit 0, `package_integrity: PASS`, `installed_metadata: NOT_SUPPLIED`, `plan_ready: false`, `selected_write_ranges: []`, `hardware_access: false` and `installation_authorized: false`. Stop on rejection. This is Python 3.8+ standard-library-only offline checking. The install launcher default contacts hardware and is NOT this offline step.

