**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-PREVIOUS-COMMAND-REPEAT-v1`. Application: **1437888 bytes**, SHA-256 `13cec88262afdfa641eb0fb4927fe7903abf2863295344ff316418707ba49b7f`. Firmware source checkpoint: `820a575a45e5a4f644921d663a650110667a6ab2`. These identify the local candidate, not installed device bytes.

Use only after a separately authorized owner installation. These are small benign TextEdit checks, not requests to repeat the eight accepted baseline trials. Record the actual assigned request ID, dashboard terminal status and visible text separately; HTTP 202 or a Completed label alone does not prove exact typed output. Leave unavailable boot/session evidence unknown.

1. Confirm the new dashboard Build ID, authenticated Route B status and STOP availability. Do not retrieve saved secrets. Open blank TextEdit, plain text mode.
2. Run the following once; expect `T05R:xxxx:DONE` plus one newline and matching Completed:

```ducky
DELAY 5000
STRING T05R:
STRING x
REPEAT 3
STRING :DONE
ENTER
```

3. Inline control, once; expect `T05I:xxx:DONE` plus one newline and matching Completed:

```ducky
DELAY 5000
STRING T05I:
REPEAT 3 STRING x
STRING :DONE
ENTER
```

4. On blank TextEdit, first-line `REPEAT 3` must compile-reject at line 1, code 14, with no TextEdit output.
5. Only if needed, run `DELAY 5000`, `HOLD SHIFT`, `DELAY 1000`, `REPEAT 20`, `RELEASE SHIFT`, `STRING SHOULD_NOT_APPEAR`; press dashboard STOP during the delay. Expect cancellation and no suffix; manually type lowercase `a` to check recovery. Do not automatically retry a failed or ambiguous trial.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks Privacy Fix 1 and the later dashboard/editor/static-response repairs. It is a standalone application, not a full-device restore; it cannot restore deleted scripts or past settings. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

