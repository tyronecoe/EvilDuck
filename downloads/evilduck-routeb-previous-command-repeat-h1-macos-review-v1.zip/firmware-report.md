**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-PREVIOUS-COMMAND-REPEAT-v1`. Application: **1437888 bytes**, SHA-256 `13cec88262afdfa641eb0fb4927fe7903abf2863295344ff316418707ba49b7f`. Firmware source checkpoint: `820a575a45e5a4f644921d663a650110667a6ab2`. These identify the local candidate, not installed device bytes.

The application was clean-built from committed source `820a575a45e5a4f644921d663a650110667a6ab2`. Every selected compile input is bound to its Git blob in build-inputs.json and source-attestation.json. The verifier is from that same checkpoint, with no post-build source or verifier delta. build-receipt.json retains the complete 190-assert release chain, actual static-response linkage and compiled/linked standalone REPEAT proof.

Standalone `REPEAT 1..128` means additional executions of an eligible preceding leaf; inline `REPEAT 2..128 leaf` retains total-count semantics. The whole program still fits at most 128 IR instructions. Comments/directives preserve eligible history, while runtime structural boundaries, state commands and multiline blocks clear it. Standalone chaining rejects. These are bounded EvilDuck policies, not blanket Hak5 DS3 certification. INJECT_VAR is unchanged and is not an inline-REPEAT leaf.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks Privacy Fix 1 and the later dashboard/editor/static-response repairs. It is a standalone application, not a full-device restore; it cannot restore deleted scripts or past settings. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

