**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

This package authorizes no installation, boot, physical test or script execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-STATIC-RESPONSE-REPAIR-v1`. Application: **1437696 bytes**, SHA-256 `d5fe0932fe915443a5e53030969c6792409f719d427681304a7102355b2d7946`. Firmware source: `68f7fb2de5af2988a3136eb9222fb8c3e7dee8f5`. These are exact verified new artifacts, not a claim about installed device bytes.

First, extract into a new folder, keep EvilDuck **unplugged**, and run only:

```bash
python3 preflight.py --directory .
```

Expect exit 0, package_integrity=PASS, installed_metadata=NOT_SUPPLIED, plan_ready=false, selected_write_ranges=[], hardware_access=false and installation_authorized=false. Stop on rejection. This command is offline; Python 3.8+ standard library only. The install launcher default performs hardware checks and is NOT this offline step.

The new application was clean-built from committed source `68f7fb2de5af2988a3136eb9222fb8c3e7dee8f5`, including the reviewed static-response delta. build-inputs.json and source-attestation.json bind those Git blobs. A host-verifier-only correction at `89d499fdb4dde13782cb09c7882ab55cc604a4dd` reverified the unchanged compiled image; the compiler context remains the original source commit. The attestation retains all 26 original compile-input rows, with only the explicitly verified target-verifier row different in the later checkout. No old uncommitted-build provenance is reused. The full inherited link/disassembly safeguards and new actual streaming-response proof are recorded in build-receipt.json. postcompile-completion.json records the host-only completion helper `520716462ffd66858a686e6c3a06eae037b3c5d4`, unchanged image/input hashes and its exact read-only compiler linker-location query; it did not compile firmware.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It does not contain Privacy Fix 1 or the subsequent dashboard/editor/static-response repairs. It is standalone application code, not a complete flash/filesystem recovery image. Application rollback does not restore deleted scripts or past settings. Preserve every existing backup.

The inherited source-stage identity `ROUTEB-RIGHT-MODIFIERS-H1-EXPERIMENTAL-v1` is historical provenance, NOT this candidate Build ID. Prior keyboard/right-modifier, lock-wait, executed STOP and scoped privacy milestones remain closed. Four historical rm-*.txt files are provenance only; do not execute them for this transport repair.

The previous editor-safety image `e825a8fb8e1c52ec998509b0191939e47572806b156ca591e51be1ece356fff0` remains historical evidence: the owner observed empty JavaScript/Checking on hardware. It is **not a known-good recovery image**. The new candidate is not declared fixed on hardware before separate owner acceptance.

Read OWNER-CHECK.md, INSTALL-MAC.md and ROLLBACK-MAC.md. This release repairs static resource serving and preserves the existing authentication/editor/keyboard paths.
