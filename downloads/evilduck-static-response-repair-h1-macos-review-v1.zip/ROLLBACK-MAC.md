**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

This package authorizes no installation, boot, physical test or script execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It does not contain Privacy Fix 1 or the subsequent dashboard/editor/static-response repairs. It is standalone application code, not a complete flash/filesystem recovery image. Application rollback does not restore deleted scripts or past settings. Preserve every existing backup.

First, extract into a new folder, keep EvilDuck **unplugged**, and run only:

```bash
python3 preflight.py --directory .
```

Expect exit 0, package_integrity=PASS, installed_metadata=NOT_SUPPLIED, plan_ready=false, selected_write_ranges=[], hardware_access=false and installation_authorized=false. Stop on rejection. This command is offline; Python 3.8+ standard library only. The install launcher default performs hardware checks and is NOT this offline step.

Only after separate physical authorization, the existing Mac workflow uses `bash install-macos.sh --action check --port CURRENT_PORT`, then separately `bash install-macos.sh --action install --port CURRENT_PORT`; deliberate rollback uses `bash rollback-macos.sh --port CURRENT_PORT`. Never run the placeholder literally. Rediscover the port after reconnects. High Sierra 10.13.6, Bash 3.2, Python 3.8+ and preinstalled esptool 4.12.0 remain the target; no dependency is installed/downloaded by this package. Native platform and physical dashboard acceptance are pending.

The unchanged installer checks ESP32-S3/16 MiB, security, exact current partition table/OTA metadata, images and bounded ranges. It creates a new **private full-flash backup before its final INSTALL confirmation** (or ROLLBACK confirmation); it may contain credentials, scripts and settings and remains if final confirmation is declined. Keep backups and raw receipts private. No existing backup is deleted or overwritten. Both application slots are bounded at 0x10000 and 0x750000 within 0x740000-byte slots. Bootloader, partition table, NVS, OTA metadata, SPIFFS and coredump are excluded. No automatic reset/reboot, retry, format, settings reset or script Start occurs. Stop on write/compare failure for a separate recovery review.

The inherited source-stage identity `ROUTEB-RIGHT-MODIFIERS-H1-EXPERIMENTAL-v1` is historical provenance, NOT this candidate Build ID. Prior keyboard/right-modifier, lock-wait, executed STOP and scoped privacy milestones remain closed. Four historical rm-*.txt files are provenance only; do not execute them for this transport repair.

The previous editor-safety image `e825a8fb8e1c52ec998509b0191939e47572806b156ca591e51be1ece356fff0` remains historical evidence: the owner observed empty JavaScript/Checking on hardware. It is **not a known-good recovery image**. The new candidate is not declared fixed on hardware before separate owner acceptance.

