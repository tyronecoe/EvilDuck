**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-DEFINE-LABELS-H1-v1`. Application: **1438048 bytes**, SHA-256 `167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30`. Firmware source checkpoint: `5d9176dd15f722ffe20d219d33684da7461d1754`. These identify the local candidate, not installed device bytes.

Extract into a new folder and keep EvilDuck **unplugged**. Run only:

```bash
python3 preflight.py --directory .
```

Expect exit 0, `package_integrity: PASS`, `installed_metadata: NOT_SUPPLIED`, `plan_ready: false`, `selected_write_ranges: []`, `hardware_access: false` and `installation_authorized: false`. Stop on rejection. This is Python 3.8+ standard-library-only offline checking. The install launcher default contacts hardware and is NOT this offline step.

The application was clean-built from committed source `5d9176dd15f722ffe20d219d33684da7461d1754`. Every selected compile input is bound to its Git blob in build-inputs.json and source-attestation.json. The verifier is from that same checkpoint, with no post-build source or verifier delta. build-receipt.json retains the complete 190-assert release chain, actual static-response linkage, compiled/linked standalone REPEAT proof and DEL alias source/object/linked-table witnesses, plus the bounded DEFINE compiler layout and workspace proof.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks Privacy Fix 1 and the later dashboard/editor/static-response repairs. It is a standalone application, not a full-device restore; it cannot restore deleted scripts or past settings. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

Read OWNER-CHECK.md before any separately authorized physical action.

Only after separate physical authorization, use the owner-established ROM-entry procedure and rediscover the current `/dev/cu.usbmodem*` port after reconnecting. Future commands are `bash install-macos.sh --action check --port CURRENT_PORT`, then separately `bash install-macos.sh --action install --port CURRENT_PORT`. Deliberate rollback uses `bash rollback-macos.sh --port CURRENT_PORT`. Never run the placeholder literally. The supported host is macOS High Sierra 10.13.6, Bash 3.2, Python 3.8+ and preinstalled esptool 4.12.0; no dependency download/install occurs. Hardware compatibility remains ESP32-S3/16 MiB, PSRAM disabled.

The source-stage label `ROUTEB-RIGHT-MODIFIERS-H1-EXPERIMENTAL-v1` is historical provenance, not this candidate Build ID.

The unchanged installer refuses unsupported chip, security, partition and OTA states. It creates a new **private full-flash backup before its final INSTALL confirmation** (or ROLLBACK confirmation). That backup may contain credentials, scripts and settings and remains if confirmation is declined. No existing backup is deleted or overwritten. Keep backups and raw device receipts private.

Only the two application regions at 0x10000 and 0x750000, each bounded by 0x740000 bytes, are proposed writes. Bootloader, partition table, NVS, OTA metadata, SPIFFS and coredump are excluded. No automatic reboot/reset, retry, formatting, settings reset or script Start occurs. A failed write/compare requires stopping in ROM for separate recovery review. Matching flash bytes do not establish boot, USB or TextEdit success.

