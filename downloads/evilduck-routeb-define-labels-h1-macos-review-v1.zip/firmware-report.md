**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-DEFINE-LABELS-H1-v1`. Application: **1438048 bytes**, SHA-256 `167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30`. Firmware source checkpoint: `5d9176dd15f722ffe20d219d33684da7461d1754`. These identify the local candidate, not installed device bytes.

The application was clean-built from committed source `5d9176dd15f722ffe20d219d33684da7461d1754`. Every selected compile input is bound to its Git blob in build-inputs.json and source-attestation.json. The verifier is from that same checkpoint, with no post-build source or verifier delta. build-receipt.json retains the complete 190-assert release chain, actual static-response linkage, compiled/linked standalone REPEAT proof and DEL alias source/object/linked-table witnesses, plus the bounded DEFINE compiler layout and workspace proof.

DEFINE labels now admit at most **31 bytes**, excluding the terminating NUL and including `#` when present. The constant-name storage cell is 32 bytes. This is an EvilDuck capacity policy, not an asserted official DS3 maximum. Labels at 32 bytes reject Identifier/code 6 before output. Ordinary variable/function names and all other source, line, IR, text and constant-slot limits remain unchanged. The compiler workspace remains 4096 bytes; no heap allocation or recursive macro semantics are introduced.

The pinned OS_DETECTION extension now passes its 27-byte DEFINE label; its actual next compile-only diagnostic is documented in the focused receipt. This is parser progress, not a working OS detector. Enumeration telemetry, OS symbols, USB mode/identity and lock lifecycle dependencies remain unsupported or reference-unresolved. No host OS probe is implemented or run. Unknown lock feedback stays unknown.

Existing DEL/DELETE forward-delete mapping, DEL() functions, bounded standalone/inline REPEAT, H1, right modifiers, STOP/cleanup, privacy, dashboard and EDR1 remain preserved.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks Privacy Fix 1 and the later dashboard/editor/static-response repairs. It is a standalone application, not a full-device restore; it cannot restore deleted scripts or past settings. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

