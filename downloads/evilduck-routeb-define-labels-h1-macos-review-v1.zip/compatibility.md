**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

DEFINE labels now admit at most **31 bytes**, excluding the terminating NUL and including `#` when present. The constant-name storage cell is 32 bytes. This is an EvilDuck capacity policy, not an asserted official DS3 maximum. Labels at 32 bytes reject Identifier/code 6 before output. Ordinary variable/function names and all other source, line, IR, text and constant-slot limits remain unchanged. The compiler workspace remains 4096 bytes; no heap allocation or recursive macro semantics are introduced.

The pinned OS_DETECTION extension now passes its 27-byte DEFINE label; its actual next compile-only diagnostic is documented in the focused receipt. This is parser progress, not a working OS detector. Enumeration telemetry, OS symbols, USB mode/identity and lock lifecycle dependencies remain unsupported or reference-unresolved. No host OS probe is implemented or run. Unknown lock feedback stays unknown.

Existing DEL/DELETE forward-delete mapping, DEL() functions, bounded standalone/inline REPEAT, H1, right modifiers, STOP/cleanup, privacy, dashboard and EDR1 remain preserved.

Existing H1/right modifiers, lock waits, privacy, editor/dashboard/static responses, STOP and EDR1 are retained. Physical High Sierra/iPhone acceptance of this candidate remains pending.
