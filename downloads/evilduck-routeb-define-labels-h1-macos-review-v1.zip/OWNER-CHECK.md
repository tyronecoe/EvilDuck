**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-DEFINE-LABELS-H1-v1`. Application: **1438048 bytes**, SHA-256 `167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30`. Firmware source checkpoint: `5d9176dd15f722ffe20d219d33684da7461d1754`. These identify the local candidate, not installed device bytes.

Use only after a separately authorized owner installation. These are three harmless TextEdit constant-substitution checks (D01_DEFINE_27.txt, D02_DEFINE_31.txt and D03_DEFINE_32_Rejected.txt inside this ZIP), not a repeat of accepted DEL or other baseline milestones. Use separate blank plain-text TextEdit documents, US input and Caps Lock off. Submit once through authenticated Route B, then focus the intended Mac document during the initial five-second delay. Record full running build ID, actual request ID/terminal status and visible output separately; completion alone does not prove host behavior. Leave unavailable session/receipt fields unknown.

1. Official 27-byte name: expect exactly `DEFINE27OK` plus one newline and matching Completed.

```ducky
DEFINE #WINDOWS_HOST_REQUEST_COUNT DEFINE27OK
DELAY 5000
STRING #WINDOWS_HOST_REQUEST_COUNT
ENTER
```

2. Maximum 31-byte name: expect exactly `DEFINE31OK` plus one newline and matching Completed.

```ducky
DEFINE #ABCDEFGHIJKLMNOPQRSTUVWXYZ1234 DEFINE31OK
DELAY 5000
STRING #ABCDEFGHIJKLMNOPQRSTUVWXYZ1234
ENTER
```

3. First-over-limit 32-byte name: expect compile rejection at physical line 1, code 6, and blank TextEdit; no STRING executes.

```ducky
DEFINE #ABCDEFGHIJKLMNOPQRSTUVWXYZ12345 REJECTED
DELAY 5000
STRING SHOULD_NOT_APPEAR
ENTER
```

Do not repair output before recording it or automatically retry an ambiguous trial. STOP remains available. No test opens a shell, reads host files, accesses credentials or probes the OS.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks Privacy Fix 1 and the later dashboard/editor/static-response repairs. It is a standalone application, not a full-device restore; it cannot restore deleted scripts or past settings. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

