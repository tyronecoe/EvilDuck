**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-DEFINE-LABELS-H1-v1`. Application: **1438048 bytes**, SHA-256 `167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30`. Firmware source checkpoint: `5d9176dd15f722ffe20d219d33684da7461d1754`. These identify the local candidate, not installed device bytes.

The application was clean-built from committed source `5d9176dd15f722ffe20d219d33684da7461d1754`. Every selected compile input is bound to its Git blob in build-inputs.json and source-attestation.json. The verifier is from that same checkpoint, with no post-build source or verifier delta. build-receipt.json retains the complete 190-assert release chain, actual static-response linkage, compiled/linked standalone REPEAT proof and DEL alias source/object/linked-table witnesses, plus the bounded DEFINE compiler layout and workspace proof.

Extract into a new folder and keep EvilDuck **unplugged**. Run only:

```bash
python3 preflight.py --directory .
```

Expect exit 0, `package_integrity: PASS`, `installed_metadata: NOT_SUPPLIED`, `plan_ready: false`, `selected_write_ranges: []`, `hardware_access: false` and `installation_authorized: false`. Stop on rejection. This is Python 3.8+ standard-library-only offline checking. The install launcher default contacts hardware and is NOT this offline step.

