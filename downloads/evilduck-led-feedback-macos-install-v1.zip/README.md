Read INSTALL-MAC.md first. ROLLBACK-MAC.md returns to the identified prior573a8671 review package; current board image is unverified.
Software/package review only; no physical installation authorization. Caps Lock and LED feedback remain physically unverified.
