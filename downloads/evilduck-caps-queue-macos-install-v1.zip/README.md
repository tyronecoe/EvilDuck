Read INSTALL-MAC.md first. ROLLBACK-MAC.md returns to the exact c20dc399 application.
Software/package review only; no physical installation authorization. Caps Lock and LED feedback remain physically unverified.
