#!/bin/bash
# Bound package launcher; deliberate rollback only, no implicit retry.
set -eu
for option in "$@"; do
  case "$option" in --action|--action=*) echo "STOP: rollback action cannot be overridden" >&2; exit 2;; esac
done
cd "$(dirname "$0")"
exec python3 installer.py --action rollback "$@"
