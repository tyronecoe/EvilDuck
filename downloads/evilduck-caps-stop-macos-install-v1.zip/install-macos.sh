#!/bin/bash
# Bound package launcher; check is the default action.
set -eu
cd "$(dirname "$0")"
exec python3 installer.py "$@"
