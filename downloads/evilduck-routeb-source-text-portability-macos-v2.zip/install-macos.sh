#!/bin/bash
# Bound review package. Default check only; physical installation requires owner authorization.
set -eu
cd "$(dirname "$0")"
exec python3 installer.py "$@"
