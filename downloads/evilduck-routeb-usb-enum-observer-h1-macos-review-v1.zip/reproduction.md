**CAPTURE-ONLY REVIEW CANDIDATE — NOT INSTALLED — NO VALIDATED OS RULE.**

This is the single authorized evidence-gathering stage, not an OS detector release. It never reports a positive OS classification, starts a payload automatically or changes USB identity. H1 remains opt-in and experimental; canonical Hak5 numeric encoding remains unresolved.

Build ID: `ROUTEB-USB-ENUM-OBSERVER-H1-v1`. Capture application: **1445008 bytes**, SHA-256 `e60af8a1b53ab2ba9e7c79b4ff821719ddd06a0a55384dd987288c4189aed6a9`. Firmware checkpoint: `7472de1e0edf123a9fcdf9d1d4feb1b38250280e`. This is an artifact identity, not installed device readback.

The committed source, actual ELF/application, linked wrapper, unchanged descriptors/dependencies and full inherited 190-assert release chain are bound in build-receipt.json and source-attestation.json. There is no post-compilation verifier delta. Native/mock results are software evidence; they do not establish actual USB capture or detection accuracy.

Keep EvilDuck **unplugged**, extract into a new folder and run only:

```bash
python3 preflight.py --directory .
```

Expect integrity PASS, exit 0, `plan_ready: false`, empty write ranges, `installed_metadata: NOT_SUPPLIED`, and hardware/installation authorization false. The offline checker validates the nested working-return ZIP without executing it or contacting hardware.

