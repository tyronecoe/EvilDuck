**CAPTURE-ONLY REVIEW CANDIDATE — NOT INSTALLED — NO VALIDATED OS RULE.**

This is the single authorized evidence-gathering stage, not an OS detector release. It never reports a positive OS classification, starts a payload automatically or changes USB identity. H1 remains opt-in and experimental; canonical Hak5 numeric encoding remains unresolved.

The observer records at most 64 whitelisted USB request headers and lifecycle/session boundaries in RAM during five seconds from its first foreground service, preserving the bounded early-boot prefix captured before Arduino setup. It captures request type/code, wValue, wIndex, wLength and ordering, not payload bodies, string/descriptor contents, HID report contents, keystrokes, host files or credentials. Overflow, incomplete capture, generation mismatch and missing data remain UNKNOWN. No counter threshold, missing LED or known-Mac connection is used to guess an OS. Captures are not uploaded automatically or learned persistently.

Existing keyboard behavior, STOP/cleanup, privacy, LED protocol, DEL, DEFINE and H1 are retained. No OS detector, new USB identity, mode or active probe is added.
