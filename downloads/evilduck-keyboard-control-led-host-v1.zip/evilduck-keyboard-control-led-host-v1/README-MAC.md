# Optional fixed-message host kit for the keyboard-control candidate

This is the passed fixed-message workflow with only its expected firmware build
identifier changed to `ROUTEB-KEYBOARD-CONTROL-20261022-v1`. It intentionally
refuses the previous installed firmware; the previous kit remains available for
that image. No EDR1 framing, message, CRC, timing, authentication, capability probe,
cleanup or successful-result validation changed. Native execution of this build
binding remains pending; the previous configuration's physical PASS is historical.

Do not repeat the full LED test automatically for an unrelated keyboard change.
This optional kit is supplied so the exact new build pin will not prevent a future
separately owner-chosen regression check. It does not install firmware.

After unzipping into Downloads, the command is:

```bash
bash "$HOME/Downloads/evilduck-keyboard-control-led-host-v1/run-mac.sh"
```

Use macOS10.13.6, existing Apple CLT, Python3.8+, and the existing dashboard Wi-Fi
connection on the Mac and iPhone. Keep all scripts idle. The launcher prints actual
USB303A:1001 serials; choose the exact unique usable interface. Enter the existing
local dashboard address and the hidden Web UI password. Never put a password in
arguments or evidence. Type PROBE for the four device-confirmed Gray-cycle steps,
then SEND for one explicitly armed fixed 17-byte message. No automatic retry occurs.
After the authenticated exact-message result, use iPhone Observe LEDs / refresh and
View test data, preserve a screenshot, and only then type VIEWED. Keep the Desktop
receipt folder, Terminal output, host/build metadata and screenshot from that run.

Only EVILDUCK TEST 123 is sent. Ctrl-C triggers bounded independent best-effort
Caps/Num output restoration; it does not prove global Caps restoration. Overall
limit600 seconds; per-step evidence4seconds; sender90-second soft/95-second
watchdog; direct local HTTP2-second deadline. OS stalls/unplug/forced exits can
prevent cleanup. Missing capability, changed session, stale/wrong probe evidence,
new receiver errors, historical completion or wrong message cannot pass.

The original detailed workflow instructions are preserved in SOURCE-README.md.
Their old firmware identity and old folder name describe the historical kit;
use this README's build identity and command for this explicitly bound variant.
No arbitrary message, capture, global Caps correction, firmware or installer is
included. Windows behavior is unverified.
