**EXPERIMENTAL — REVIEW ONLY — NOT AUTHORIZED FOR FLASHING.**

Downloading or checking this package does not authorize device access, installation, boot or testing. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-DASHBOARD-CLEANUP-v1`. Application: 1428208 bytes; SHA-256 `e0ae270554c28dbc7f5634a5879c4ea56dd39b60e37b4c2de5cb9493520b97d1`. Firmware source: `0db1f980e0ed05390d71fe9e92178304d7a3bc24`.

Supported interfaces: macOS High Sierra 10.13.6, Bash 3.2, Python 3.8+ (owner: 3.8.10), and preinstalled esptool 4.12.0. No dependencies are installed or downloaded. The first check reads package files only, without USB or network access:

```bash
python3 preflight.py --directory .
```

Expect exit 0, `package_integrity: PASS`, `installed_metadata: NOT_SUPPLIED`, `plan_ready: false`, `selected_write_ranges: []`, `hardware_access: false`, and `installation_authorized: false`. Stop on rejection. The launcher default is a hardware check, not this offline check.

This additive release moves diagnostic content behind an opt-in Diagnostics area and retains Privacy Fix 1. Read OWNER-CHECK.md, INSTALL-MAC.md and ROLLBACK-MAC.md. The exact 201-file composition differs from the privacy base in two files (webfiles.h and the build-ID header); 199 are unchanged. Its cumulative H1 delta is four files, with 197 unchanged. The historical H1 and privacy source manifests remain separate from the final dashboard manifest.

The exact older accepted source/text-v2 rollback is a standalone application: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It does not contain Privacy Fix 1 or this dashboard cleanup. It is not a merged image or a complete recovery set. Preserve every existing backup unchanged.

The four historical `rm-*.txt` fixtures and owner evidence are provenance only, not requests to repeat accepted trials. Nothing starts a payload automatically. No new keyboard behavior or tested LED-protocol change is introduced. Native High Sierra and physical dashboard behavior remain pending owner review.
