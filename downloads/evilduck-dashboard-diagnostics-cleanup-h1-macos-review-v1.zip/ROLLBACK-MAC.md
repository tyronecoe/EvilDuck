**EXPERIMENTAL — REVIEW ONLY — NOT AUTHORIZED FOR FLASHING.**

Downloading or checking this package does not authorize device access, installation, boot or testing. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

The exact older accepted source/text-v2 rollback is a standalone application: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It does not contain Privacy Fix 1 or this dashboard cleanup. It is not a merged image or a complete recovery set. Preserve every existing backup unchanged.

Supported interfaces: macOS High Sierra 10.13.6, Bash 3.2, Python 3.8+ (owner: 3.8.10), and preinstalled esptool 4.12.0. No dependencies are installed or downloaded. The first check reads package files only, without USB or network access:

```bash
python3 preflight.py --directory .
```

Expect exit 0, `package_integrity: PASS`, `installed_metadata: NOT_SUPPLIED`, `plan_ready: false`, `selected_write_ranges: []`, `hardware_access: false`, and `installation_authorized: false`. Stop on rejection. The launcher default is a hardware check, not this offline check.

Only after separate authorization, use `bash rollback-macos.sh --port CURRENT_PORT` with a freshly rediscovered/verified ROM port. Do not run the placeholder literally. The unchanged launcher selects the deliberate rollback action; it never retries or chooses rollback automatically. It repeats chip, security, layout, OTA, image and bounded-range checks, creates a new private full-flash backup before the final ROLLBACK confirmation, writes the exact rollback image to both app slots and compares both. No metadata/data partition write or automatic reboot is requested. If an earlier operation failed, remain in ROM and review the evidence before any new action.
