**EXPERIMENTAL — REVIEW ONLY — NOT AUTHORIZED FOR FLASHING.**

Downloading or checking this package does not authorize device access, installation, boot or testing. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-DASHBOARD-CLEANUP-v1`. Application: 1428208 bytes; SHA-256 `e0ae270554c28dbc7f5634a5879c4ea56dd39b60e37b4c2de5cb9493520b97d1`. Firmware source: `0db1f980e0ed05390d71fe9e92178304d7a3bc24`.

Supported interfaces: macOS High Sierra 10.13.6, Bash 3.2, Python 3.8+ (owner: 3.8.10), and preinstalled esptool 4.12.0. No dependencies are installed or downloaded. The first check reads package files only, without USB or network access:

```bash
python3 preflight.py --directory .
```

Expect exit 0, `package_integrity: PASS`, `installed_metadata: NOT_SUPPLIED`, `plan_ready: false`, `selected_write_ranges: []`, `hardware_access: false`, and `installation_authorized: false`. Stop on rejection. The launcher default is a hardware check, not this offline check.

The exact older accepted source/text-v2 rollback is a standalone application: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It does not contain Privacy Fix 1 or this dashboard cleanup. It is not a merged image or a complete recovery set. Preserve every existing backup unchanged.

Read OWNER-CHECK.md. Only after separate physical authorization, use the owner-established ROM-entry procedure and rediscover the current `/dev/cu.usbmodem*` port after reconnects. Do not assume a previous suffix. The inherited source-stage label `ROUTEB-RIGHT-MODIFIERS-H1-EXPERIMENTAL-v1` identifies the historical H1 layer, not this dashboard candidate; require the new Build ID above and exact application hash. The supported board is ESP32-S3 with 16 MiB flash; PSRAM remains disabled.

The unchanged application-only installer refuses unsupported chip/security/layout/OTA states. Its future actions are `bash install-macos.sh --action check --port CURRENT_PORT` and, only when separately authorized, `bash install-macos.sh --action install --port CURRENT_PORT` with that freshly verified port. Do not run the placeholder literally. It requires esptool 4.12.0 and owner-controlled ROM mode; there is no automatic reset, reboot, retry, script Start or HID action.

Before writing, the existing installer creates a new **private full-flash backup** on the Desktop, before its final INSTALL confirmation. That backup may include passwords, settings and scripts. Declining the final confirmation leaves it in place. No existing backup is deleted or overwritten. Keep the backup and raw local evidence private.

The reviewed table and narrow app0 OTA initializer must match exactly. The only proposed writes are the same application in both OTA slots at 0x10000 and 0x750000, bounded by each 0x740000-byte slot and image-rounded sectors. The manifest gives exact ranges. Bootloader, partition table, NVS, OTA data, SPIFFS and coredump are excluded. No format, settings reset, repair or metadata rewrite is provided. A failed write/compare requires stopping in ROM and separate recovery review. A successful comparison is not a boot or USB test.
