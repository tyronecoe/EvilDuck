**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-DEL-ALIAS-H1-v1`. Application: **1437888 bytes**, SHA-256 `d1571be81619e464ee997d0ba8ebbf7e7b8a8b4252e4debc9d9144b9ebe6b379`. Firmware source checkpoint: `2e3efa295d46aef55b4d39af9cf3a9a40bb70422`. These identify the local candidate, not installed device bytes.

Use only after a separately authorized owner installation. These are small benign TextEdit checks, not requests to repeat accepted baseline milestones. Record the actual assigned request ID, dashboard terminal status and visible text separately; HTTP 202 or a Completed label alone does not prove exact typed output. Leave unavailable boot/session evidence unknown.

1. Confirm the new dashboard Build ID, authenticated Route B status and STOP availability. Do not retrieve saved secrets. Open blank TextEdit, plain text mode.
2. Trial A: run the following once in a blank plain-text document. Expect two lines `ac` and `ac`, then matching Completed. DEL is forward delete, not Backspace.

```ducky
DELAY 5000
STRING abc
LEFTARROW
LEFTARROW
DEL
RIGHTARROW
ENTER
STRING abc
LEFTARROW
LEFTARROW
DELETE
```

3. Trial B: run once in another blank document; expect `ade` and matching Completed.

```ducky
DELAY 5000
STRING abcde
LEFTARROW
LEFTARROW
LEFTARROW
LEFTARROW
DEL
REPEAT 1
```

4. Trial C: on blank TextEdit, submit the source below once. Expect compile failure at physical line 2, code 13, and blank TextEdit. Retained malformed source rejects before the first STRING executes.

```ducky
STRING SHOULD_NOT_APPEAR
DEL extra
```

STOP remains available. Do not automatically retry a failed or ambiguous trial. No command above opens a shell, reads host files or accesses passwords.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks Privacy Fix 1 and the later dashboard/editor/static-response repairs. It is a standalone application, not a full-device restore; it cannot restore deleted scripts or past settings. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

