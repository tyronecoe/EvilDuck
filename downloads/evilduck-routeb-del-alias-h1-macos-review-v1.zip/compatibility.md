**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

Downloading or checking this package authorizes no hardware access, installation, boot or payload execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Exact uppercase `DEL` is an alias of `DELETE`: keyboard usage 0x4c, forward delete. Existing modifier chords, HOLD/RELEASE and supported REPEAT positions reuse the ordinary key path. `STRING DEL` and text blocks remain literal; `DEL()` functions and `$DEL` variables remain valid. Raw source byte 0x7f is still rejected. No new layout or Unicode support is added. This profile still requires the US device mapping.

Standalone `REPEAT 1..128` means additional executions of an eligible preceding leaf; inline `REPEAT 2..128 leaf` retains total-count semantics. The whole program still fits at most 128 IR instructions. Comments/directives preserve eligible history, while runtime structural boundaries, state commands and multiline blocks clear it. Standalone chaining rejects. These are bounded EvilDuck policies, not blanket Hak5 DS3 certification. INJECT_VAR is unchanged and is not an inline-REPEAT leaf.

Existing H1/right modifiers, lock waits, privacy, editor/dashboard/static responses, STOP and EDR1 are retained. Physical High Sierra/iPhone acceptance of this candidate remains pending.
