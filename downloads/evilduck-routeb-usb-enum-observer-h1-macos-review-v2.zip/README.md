**CAPTURE-ONLY REVIEW CANDIDATE — NOT INSTALLED — NO VALIDATED OS RULE.**

This is the explicitly approved bounded revision of the capture-only observer, not an OS detector release. It never reports a positive OS classification, starts a payload automatically or changes USB identity. H1 remains opt-in and experimental; canonical Hak5 numeric encoding remains unresolved.

Build ID: `ROUTEB-USB-ENUM-OBSERVER-H1-v2`. Capture application: **1450624 bytes**, SHA-256 `b7ac50eebe6fb5e3d69d97f20004e1014c46fb116845e30864f56de5de6d384e`. Firmware checkpoint: `b075e551e07f7b15124bdad3caa564c614f78ba4`. This is an artifact identity, not installed device readback.

Keep EvilDuck **unplugged**, extract into a new folder and run only:

```bash
python3 preflight.py --directory .
```

Expect integrity PASS, exit 0, `plan_ready: false`, empty write ranges, `installed_metadata: NOT_SUPPLIED`, and hardware/installation authorization false. The offline checker validates the nested working-return ZIP without executing it or contacting hardware.

Schema evilduck-usb-observer-v2 keeps the original first five-second prefix of at most 64 selected USB request headers, preserving bounded early-boot records before Arduino setup. Prefix closure and its configured SDK sample are immutable; separately labelled live samples do not rewrite that history. A separate five-second diagnostic tail ends at ten seconds total, retaining only bounded counters and first late-request/configuration witnesses. Tail observations cannot retroactively make the prefix COMPLETE. One separate first unsupported SETUP witness preserves the header, order, reason and observation time; further distinct unsupported headers remain an explicit insufficiency flag. It captures request type/code, wValue, wIndex, wLength, ordering and monotonic observation timestamps, not payload bodies, string/descriptor contents, HID report contents, keystrokes, host files or credentials. Overflow, incomplete capture, generation mismatch and missing data remain UNKNOWN. No counter threshold, missing LED or known-Mac connection is used to guess an OS. Configuration samples are SDK bookkeeping, not proof of a completed USB transaction. Timestamps are observer times, not wire timestamps; late service or timing gaps remain explicit limitations rather than invented deadline samples. Unknown values are explicit rather than synthetic zeros. Captures are not uploaded automatically or learned persistently.

**Return to your working firmware:** `working-define-labels-macos-review-v1.zip` is the original unchanged DEFINE package, **2,691,374 bytes**, SHA-256 `b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed`. It contains working application `ROUTEB-DEFINE-LABELS-H1-v1`, **1,438,048 bytes**, SHA-256 `167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30`. This WORKING_DEFINE_RETURN role is distinct from the older rollback above. Extract that nested ZIP into a separate new folder, keep the board unplugged, and run its existing `python3 preflight.py --directory .`. For a later deliberate owner return, follow the unchanged kit INSTALL-MAC.md using the established ROM-entry and rediscovered-port procedure. The action is the existing guarded install of the known working image; no new return/flash option is invented. Do not run `rollback-macos.sh` expecting the DEFINE image: that selects the older source/text-v2 image. If capture is inconclusive or keyboard behavior regresses, stop and use this working-return path. No automatic return, erase, format or settings reset occurs.

The older source/text-v2 rollback remains **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks later privacy/dashboard repairs and is not a full-device/filesystem restore. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

Read OWNER-CHECK.md, CAPTURE-CONTRACT.md, RETURN-WORKING.md and INSTALL-MAC.md. Historical rm-*.txt/DEFINE fixtures are provenance only; do not execute them for capture.
