**CAPTURE-ONLY REVIEW CANDIDATE — NOT INSTALLED — NO VALIDATED OS RULE.**

This is the explicitly approved bounded revision of the capture-only observer, not an OS detector release. It never reports a positive OS classification, starts a payload automatically or changes USB identity. H1 remains opt-in and experimental; canonical Hak5 numeric encoding remains unresolved.

The older source/text-v2 rollback remains **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It lacks later privacy/dashboard repairs and is not a full-device/filesystem restore. The e825 editor-safety candidate is not a known-good recovery image. Preserve every existing backup.

Keep EvilDuck **unplugged**, extract into a new folder and run only:

```bash
python3 preflight.py --directory .
```

Expect integrity PASS, exit 0, `plan_ready: false`, empty write ranges, `installed_metadata: NOT_SUPPLIED`, and hardware/installation authorization false. The offline checker validates the nested working-return ZIP without executing it or contacting hardware.

The supported host remains Intel macOS High Sierra 10.13.6, Bash 3.2, Python 3.8+ and preinstalled esptool 4.12. Use only the unchanged installer instructions; no dependency downloads occur. It refuses unsupported chip, security, partition and OTA states. It creates a new **private full-flash backup before its final INSTALL confirmation** (or ROLLBACK confirmation); that file may contain credentials, settings and scripts and remains if confirmation is declined. No existing backup is deleted or overwritten. Writes remain limited to the two application regions at 0x10000 and 0x750000; bootloader, partition table, NVS, OTA metadata and filesystems are excluded. No automatic reboot, retry or payload start occurs.

Read OWNER-CHECK.md before any separately owner-operated physical action. Use the established ROM-entry procedure and rediscover the current `/dev/cu.usbmodem*` port after reconnecting. Future commands are `bash install-macos.sh --action check --port CURRENT_PORT`, then separately `bash install-macos.sh --action install --port CURRENT_PORT`. Deliberate older rollback uses `bash rollback-macos.sh --port CURRENT_PORT`. Never run the placeholder literally. These commands contact hardware and are not the offline preflight above. Hardware compatibility remains ESP32-S3 with 16 MiB flash and PSRAM disabled. The source-stage label `ROUTEB-RIGHT-MODIFIERS-H1-EXPERIMENTAL-v1` is historical provenance, not this candidate build ID.

**Return to your working firmware:** `working-define-labels-macos-review-v1.zip` is the original unchanged DEFINE package, **2,691,374 bytes**, SHA-256 `b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed`. It contains working application `ROUTEB-DEFINE-LABELS-H1-v1`, **1,438,048 bytes**, SHA-256 `167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30`. This WORKING_DEFINE_RETURN role is distinct from the older rollback above. Extract that nested ZIP into a separate new folder, keep the board unplugged, and run its existing `python3 preflight.py --directory .`. For a later deliberate owner return, follow the unchanged kit INSTALL-MAC.md using the established ROM-entry and rediscovered-port procedure. The action is the existing guarded install of the known working image; no new return/flash option is invented. Do not run `rollback-macos.sh` expecting the DEFINE image: that selects the older source/text-v2 image. If capture is inconclusive or keyboard behavior regresses, stop and use this working-return path. No automatic return, erase, format or settings reset occurs.

