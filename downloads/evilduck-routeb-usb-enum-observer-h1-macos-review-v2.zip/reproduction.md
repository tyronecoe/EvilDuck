**CAPTURE-ONLY REVIEW CANDIDATE — NOT INSTALLED — NO VALIDATED OS RULE.**

This is the explicitly approved bounded revision of the capture-only observer, not an OS detector release. It never reports a positive OS classification, starts a payload automatically or changes USB identity. H1 remains opt-in and experimental; canonical Hak5 numeric encoding remains unresolved.

Build ID: `ROUTEB-USB-ENUM-OBSERVER-H1-v2`. Capture application: **1450624 bytes**, SHA-256 `b7ac50eebe6fb5e3d69d97f20004e1014c46fb116845e30864f56de5de6d384e`. Firmware checkpoint: `b075e551e07f7b15124bdad3caa564c614f78ba4`. This is an artifact identity, not installed device readback.

The committed source, actual ELF/application, linked wrapper, unchanged descriptors/dependencies and full inherited 190-assert release chain are bound in build-receipt.json and source-attestation.json. There is no post-compilation verifier delta. Native/mock results are software evidence; they do not establish actual USB capture or detection accuracy.

Keep EvilDuck **unplugged**, extract into a new folder and run only:

```bash
python3 preflight.py --directory .
```

Expect integrity PASS, exit 0, `plan_ready: false`, empty write ranges, `installed_metadata: NOT_SUPPLIED`, and hardware/installation authorization false. The offline checker validates the nested working-return ZIP without executing it or contacting hardware.

