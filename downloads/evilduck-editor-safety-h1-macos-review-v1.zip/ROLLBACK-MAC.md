**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

This package authorizes no installation, boot, physical test or script execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It does not contain Privacy Fix 1 or the later dashboard/editor repairs. It is application code, not a complete flash or filesystem backup. Existing backups remain untouched.

First, extract into a new folder, keep EvilDuck **unplugged**, and run only:

```bash
python3 preflight.py --directory .
```

Expect exit 0, package_integrity=PASS, installed_metadata=NOT_SUPPLIED, plan_ready=false, selected_write_ranges=[], hardware_access=false and installation_authorized=false. Stop on rejection. This command is offline; it uses Python 3.8+ standard library only. The install launcher default performs hardware checks and is NOT this offline step.

Only after separate physical authorization, the unchanged Mac workflow uses `bash install-macos.sh --action check --port CURRENT_PORT`, then separately `bash install-macos.sh --action install --port CURRENT_PORT`; the deliberate rollback is `bash rollback-macos.sh --port CURRENT_PORT`. Never run the placeholder literally. Rediscover the port after reconnects. High Sierra 10.13.6, Bash 3.2, Python 3.8+ and preinstalled esptool 4.12.0 remain the reviewed workflow; no dependency is installed/downloaded by this package.

The installer checks ESP32-S3/16 MiB, security state, exact current partition table/OTA metadata, image integrity and bounded write ranges. It creates a new **private full-flash backup before its final INSTALL confirmation** (or ROLLBACK confirmation); it may contain credentials, scripts and settings and remains even if confirmation is declined. Keep backups/receipts private. No existing backup is deleted or overwritten. Only both application slots, 0x10000 and 0x750000 within 0x740000-byte slots, are proposed. Bootloader, table, NVS, OTA metadata, SPIFFS and coredump are excluded. No automatic reset/reboot, retry, format, settings reset or payload Start occurs. Write/compare failure requires stopping for a separate recovery review.

Rollback never restores deleted scripts or past settings. It is separately deliberate, never automatic or implied by downloading/checking this ZIP.
