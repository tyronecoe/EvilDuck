**REVIEW ONLY — NOT INSTALLED — NOT OWNER-HARDWARE-VERIFIED.**

This package authorizes no installation, boot, physical test or script execution. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: `ROUTEB-EDITOR-SAFETY-UNINSTALLED-v1`. Application: **1,437,696 bytes**, SHA-256 `e825a8fb8e1c52ec998509b0191939e47572806b156ca591e51be1ece356fff0`. It is the verified existing application; no firmware was rebuilt for packaging. The Build ID is a static candidate label, not independent proof of a device state.

First, extract into a new folder, keep EvilDuck **unplugged**, and run only:

```bash
python3 preflight.py --directory .
```

Expect exit 0, package_integrity=PASS, installed_metadata=NOT_SUPPLIED, plan_ready=false, selected_write_ranges=[], hardware_access=false and installation_authorized=false. Stop on rejection. This command is offline; it uses Python 3.8+ standard library only. The install launcher default performs hardware checks and is NOT this offline step.

Post-build source checkpoint: `1664d4f25593e6cc99dba43ff0e5d74531555a51`. The actual build ran from base `805d989c3ac50cb96025862c95916830c59f8ba7` with the recorded 17 uncommitted inputs, manifest SHA-256 `525fc3f9e95c65f81a1233f3f31eac1f321233d0dd87ac2517d5a4c2f2eab768`. source-attestation.json proves that checkpoint contains those exact file bytes; it does not claim compilation occurred after that commit. See reproduction.md for the isolated-base reproduction procedure.

Exact older source/text-v2 rollback: **1,413,200 bytes**, SHA-256 `cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02`. It does not contain Privacy Fix 1 or the later dashboard/editor repairs. It is application code, not a complete flash or filesystem backup. Existing backups remain untouched.

Read OWNER-CHECK.md, INSTALL-MAC.md and ROLLBACK-MAC.md. This package adds only the reviewed editor data-safety repair to the existing composition. Until separately installed/accepted, keep avoiding Save/editor Run after a failed load on the currently installed firmware.

The inherited source-stage identity `ROUTEB-RIGHT-MODIFIERS-H1-EXPERIMENTAL-v1` is historical provenance, NOT this candidate Build ID. Prior right-modifier, lock-wait, executed STOP and privacy milestones remain accepted within their recorded limits. The four rm-*.txt files are host provenance only; do not run/reinstall them for this review.

