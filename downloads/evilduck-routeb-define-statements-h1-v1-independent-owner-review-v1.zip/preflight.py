# Admission diagnostics additive preflight over immutable observer-v2 parent SHA256 232ef2673fcc9e29082c13c5d3c52412369f4f656c663e0a70ec9c209a994ee0
# Observer v2 additive package; immutable v1 parent SHA256 c5e8384ee40653c5b017685ce81431bc7eca4718e1a8f8b5c864ab86aff37a47
# USB enumeration observer capture package over immutable DEFINE parent 5fbe1fa388759810f40bceeb2dbaa3d16efe633352364ec4ae550ddd12fecfd7
# Bounded DEFINE-label package over immutable DEL parent 241b40e3f8284615cca8bd870022754039024a3d4d5e8316535fac5118f3b50d
# Additive DEL-alias review package; immutable REPEAT parent d095130bfb73d75ab708be338df97739227f129cecfe2a4fb60226a94f71ab29
# Bounded REPEAT preflight: inherited image/layout/OTA/installer boundaries unchanged.
# Original image/layout/OTA/read-only functions and rollback tail retained unchanged.
# Dashboard cleanup additive preflight over immutable Privacy Fix 1 parent.
# Parent SHA-256: 6b27aeeaba35346ee68da840e8d3438fe0eca34b14bb61d26a9d96ce10cf1b44
# Historical H1/source-layer identities stay historical; final dashboard identity is distinct.
# Privacy Fix 1 additive package preflight. Historical H1 parent SHA256 b8de87a5b63237e5400f95e1bfb05e54aa05f3add5d4c309d2964b09b80ce79f
# Only package identity/support inventory and additional privacy provenance checks differ.
# Additive right-side modifier package preflight; parent SHA256 5ef335b22921bd3d90fcd9b6441081a538dc635067713e727dadbf5030e0f8a6
# Additive H1 package preflight; parent SHA256 8c6d10b6e2193fe625fb86ca191c09e9f0f259d87f27535a8a0d48b940fff49b
# Additive bounded-lock-wait adaptation of tests/source_text_v2/preflight.py
# Parent SHA-256: 889d4115478b06435a1efca1915581ac002bc82c51b4258c77c280415ea03b72
# Additive source/text-portability adaptation of tests/payload_restart/preflight.py
# Parent SHA-256: 09bdecd1f57a823a3c92db8f9e879981fc6f2fbbe3bc32baac0c36a6600a5418
# Additive payload-restart adaptation of tests/text_keyboard/preflight.py
# Parent SHA-256: 65afceff0e42457238c47584b5df36e0b76b2bdd58340977b3a3aff011918778
# Additive release adaptation; historical lock-feedback preflight remains unchanged.
#!/usr/bin/env python3
"""Read-only, Python3.8+ package/layout checks. No device, serial, network or write API."""
import argparse, hashlib, importlib.util, io, json, pathlib, stat, struct, sys, zipfile, zlib
sys.dont_write_bytecode=True
RELEASE={'source_commit': '4490d6c46dc2bd72bd464939f6c6d3af37c780b2', 'firmware_source_commit': 'de683669135fe5ccc5922f9883709194400672e5', 'verification_source_commit': '5a5894effe44bdacb79f1c17f594e156cff20456', 'application_bytes': 1451184, 'application_sha256': '524805fbde1af49b908b156e0eb50de48393b8e2810efcf0eaddba931408012e', 'elf_sha256': 'cd82758717bf0e6e78aa8a582dff7b01de99ac14a62923b12cd104de8c56f490', 'build_inputs_sha256': 'ae35e5d72b2a6977725014e9b00b560e5d04880623cafba772d160279fc41b46', 'verifier_identity_sha256': '716b81a213db111f6b00832afa0e54f792cf06491fafebd3a137b44be36dd4ef', 'core_sha256': 'b9c53bd3632e049e674ea66bf6c110bf22bb51c35f0d46ae75e0f5825d069d99', 'support': ['APACHE-2.0.txt', 'DS01_STATEMENTS.txt', 'DS02_DELAY_STOP.txt', 'DS03_RECOVERY.txt', 'DS04_REJECT.txt', 'FIXTURE-SHA256.txt', 'INSTALL-MAC.md', 'OWNER-CHECK.md', 'README.md', 'RETURN-WORKING.md', 'ROLLBACK-MAC.md', 'build-inputs.json', 'gen_esp32part.py', 'independent-gate-result.json', 'independent-gate-summary.json', 'independent-layout.json', 'independent-release-receipt.json', 'independent-stack.json', 'independent-target-receipt.json', 'install-macos.sh', 'installer.py', 'original-build-report.json', 'post-build-attestation.json', 'preflight.py', 'rollback-build-receipt.json', 'rollback-macos.sh', 'source-LICENSE.txt', 'working-define-labels-macos-review-v1.zip'], 'pins': {'gen_esp32part.py': 'b82195fe2ff6b0841a8c8927e07cc90efc31695168f4c6b776194fa9b4f2950c', 'build-inputs.json': 'ae35e5d72b2a6977725014e9b00b560e5d04880623cafba772d160279fc41b46', 'ROLLBACK-MAC.md': '54f07c0b7ca345f2f7666ceb52236082fc0c8c697ba18deefb7efdbf7be86c22', 'INSTALL-MAC.md': 'a0cf7b70b0365c0638862cfde81910673a269e39c0be159d521538651b669407', 'OWNER-CHECK.md': '243ad2dbd7b5db54db3f8726b67154fe64aef62fbd39e481afdab21077ac37ef', 'independent-gate-result.json': '18cb193b9db93efc1ade6a0fef3ca57746f2dc92903d416d93d20ac7a44fef54', 'rollback-build-receipt.json': 'fc179a97b8a1768ee85161f4c6a80e648a1b96652bfd698e91d26717edf59953', 'FIXTURE-SHA256.txt': 'b8c6bb166e77ed61a89acd490e0688c74fc3aa944b32b62fe316a11ad316affa', 'independent-layout.json': '589305cac059f731e86366891531d2c291f7266abb01aed5cd1d14fcdc6b3e41', 'independent-target-receipt.json': 'f98e876c083f4662eff662923b68d5b78e315c10fb4d17b8e9182b494034bfa5', 'source-LICENSE.txt': 'b81f3e122b91e521ffe58c1a983d9551cc71b7f3f840c22499bda69bfd500ddb', 'DS01_STATEMENTS.txt': 'b50477e82339fe240bf35322c3503c401b1eb36fe1939b460d90c1e2a1aa8b1d', 'rollback-macos.sh': '6ad97fa1d58d89689e2638ec1559c2b927e7251cb99047bdb003ff3cea97321b', 'independent-gate-summary.json': '315ade3448956db3110619ca903f1807bc061a633f22c1130018ba0523387aae', 'DS04_REJECT.txt': '1b01231dbe4c9311596bd7290bef6d647cabebe5482b6fed50941b061f295369', 'install-macos.sh': '290467849471980640fcf4bd6e44d69e22ec20f1cb7f5fd4436c0dc8a83f1cd8', 'original-build-report.json': 'dbc505c2a4e96c3bcd86339e43db35fe494bdcd4a168e3590914e4f7f8a5c893', 'working-define-labels-macos-review-v1.zip': 'b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed', 'post-build-attestation.json': 'ebd136398738faf7d516f8c09e0e45b7f7daecc751359127656d283e2387ea3c', 'README.md': 'd1305fbb7675f940cb0cf1e721c12f2296787d3bf172109333a8704a70ba40ae', 'RETURN-WORKING.md': 'fd7dcbaf3dc416c660c3a101fd05ad3edc14d2365813ee7662583108343afd92', 'independent-stack.json': '9c2ef9ff8bd823624e5b6067a0a79b45a42a35e853b30ac19847680268aeeaca', 'APACHE-2.0.txt': 'cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30', 'independent-release-receipt.json': '57301298124abddccc0e25f3806329e3a5c3ec095a51346385d29954a2531cad', 'DS03_RECOVERY.txt': 'd82ef44b01389fc5b84fa207500bb582fe874e092948ba5b529a79f2b7526c19', 'DS02_DELAY_STOP.txt': '6e94feeef39ef7cb6f6cefa6e9493f83b171f7e768b707a1932cc23aae29a726'}}
# The public package replaces only RELEASE with its exact generated identity.
SOURCE=RELEASE['source_commit'] if RELEASE else None
APP_BYTES=RELEASE['application_bytes'] if RELEASE else 0
APP_SHA=RELEASE['application_sha256'] if RELEASE else None
ROLLBACK_BYTES=1413200
ROLLBACK_SHA='cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02'
TABLE_SHA='b79bde9ef4a9544411d97a31a1d326b2028213269ad0dcc643ea921230ce3d5e'
OTA_SHA='f94c5d786a7a8fab06ac5d10e33bf37711a6697636dc037559ea19cc410a17f0'
LAYOUT=[('nvs',1,2,0x9000,0x5000),('otadata',1,0,0xe000,0x2000),('app0',0,0x10,0x10000,0x740000),('app1',0,0x11,0x750000,0x740000),('spiffs',1,0x82,0xe90000,0x160000),('coredump',1,3,0xff0000,0x10000)]
SUPPORT={'README.md','OWNER-CHECK.md','INSTALL-MAC.md','ROLLBACK-MAC.md','preflight.py','installer.py','install-macos.sh','rollback-macos.sh','gen_esp32part.py','APACHE-2.0.txt','source-LICENSE.txt','build-receipt.json','rollback-build-receipt.json','firmware-report.md','test-results.json','compatibility.md','owner-evidence.md','source-manifest.json','dependency-pin.json','reproduction.md','rm-shift.txt','rm-modifier-taps.txt','rm-stop.txt','rm-malformed.txt','privacy-source-manifest.json','dashboard-source-manifest.json','reviewed-editor-source-manifest.json','editor-build-source-manifest.json','build-inputs.json','source-attestation.json','response-source-manifest.json','static-response-build-source-manifest.json','previous-repeat-source-manifest.json','previous-repeat-release-source-manifest.json','native-test-receipt.json','web-test-receipt.json','current-del-regression-receipt.json','current-define-regression-receipt.json','del-source-manifest.json','del-release-source-manifest.json','del-test-receipt.json','define-source-manifest.json','define-release-source-manifest.json','define-test-receipt.json','del-owner-closeout.md','D01_DEFINE_27.txt','D02_DEFINE_31.txt','D03_DEFINE_32_Rejected.txt','observer-source-manifest.json','observer-web-source-manifest.json','observer-release-source-manifest.json','observer-v2-source-manifest.json','observer-v2-web-source-manifest.json','observer-v2-release-source-manifest.json','observer-test-receipt.json','observer-web-test-receipt.json','CAPTURE-CONTRACT.md','evidence-gate.json','observer-v1-export-0.json','observer-v1-export-1.json','observer-v1-export-2.json','observer-v1-export-3.json','observer-v1-export-4.json','observer-v1-owner-handoff.txt','define-owner-acceptance.md','working-define-labels-macos-review-v1.zip','RETURN-WORKING.md'}
SUPPORT |= {'admission-source-manifest.json','admission-release-source-manifest.json','admission-test-receipt.json','admission-negative-controls.json','FIXTURE-SHA256.txt','AD00_PRIOR_COMPILE_LINE5.txt','AD01_INVALID_BYTE_LINE3.duck','AD02_VALID_RECOVERY.txt','BYTE-FIXTURES.md'}
ACTUAL_BUILD_ID='ROUTEB-DEFINE-STATEMENTS-H1-v1'
WORKING_ZIP_FILE='working-define-labels-macos-review-v1.zip'
WORKING_ZIP_BYTES=2691374
WORKING_ZIP_SHA='b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed'
WORKING_APP_BYTES=1438048
WORKING_APP_SHA='167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30'
WORKING_RETURN=dict(role='WORKING_DEFINE_RETURN',file=WORKING_ZIP_FILE,bytes=WORKING_ZIP_BYTES,sha256=WORKING_ZIP_SHA,build_id='ROUTEB-DEFINE-LABELS-H1-v1',application_bytes=WORKING_APP_BYTES,application_sha256=WORKING_APP_SHA,older_rollback_sha256=ROLLBACK_SHA,method='EXTRACT_SEPARATE_FOLDER_AND_USE_UNCHANGED_GUARDED_KIT')
EDITOR_BUILD_ID='ROUTEB-EDITOR-SAFETY-UNINSTALLED-v1'
ORIGINAL_BASE='805d989c3ac50cb96025862c95916830c59f8ba7'
SOURCE_CHECKPOINT=RELEASE['firmware_source_commit'] if RELEASE else None
EDITOR_HEADER_SHA='df10d10fd612ecb8be37c0c8e3a092720af463870814cab1c649e8a70304e445'
EXPECTED_RESOURCES={'INDEX_HTML': (13145, 'b12d84e89f88d1f9565192cebc940b79e4de0ee94b41f8ba186579843c571ed8'), 'INDEX_JS': (34649, 'd7fa4bcdf0d49f5770c09ffedd3515ddcbb6dbaad5f5a55091240d7c313e0cfa'), 'SETTINGS_HTML': (5390, 'f545e9154b2cf8d5e6573075008a87704a786bceb44fc625376b7a7d64bdd4e8'), 'SETTINGS_JS': (10503, '7ef1cc50fdbb772e7dedb2629c6004b744f5ef9b7a0e35f2abb7b93ceb2af686'), 'STYLE_CSS': (31976, '572d65a22ddb9892bea169a8ea43ca078e3aa9207519b7cd58cb465de39428da')}
EXPECTED_WIRE={'INDEX_HTML': (13144, '790a671f3feca307df39b200cdd4fd9ae27d0e8b4ca13d825328f25e400fe5eb'), 'SETTINGS_HTML': (5389, 'ef9f7093b2e537dc18ab2100bc03c9cbc6a7b9886291ace5c1fcfa12c5c1ce3a'), 'TERMINAL_HTML': (1324, 'cd341048c6d0a1211bd8ff0670203d706f0247eab8c72db08243d5529ba89d51'), 'CREDITS_HTML': (1746, '06d0f8e850c968b34a418d8b6462018811c0e7dd4d865f40c8c96644f87a2e8d'), 'ERROR404_HTML': (869, 'a8e89049a587a61fc7b2bcdd21ccedd578a4b1026df0e796be2a39108fc6da9d'), 'STYLE_CSS': (31975, '37df80940a89fb76e7373a1f1cadb687551b068cc94e65d61a18e03100cbed50'), 'INDEX_JS': (34648, '681192a3aa5474d4a313779ea9a661a2b234c73965f12030145bef7fbcf4409f'), 'SETTINGS_JS': (10502, '37cbfdbd4a4dafc50ec34c79fc862ec1c28ca69eb47d393d1f3d6e8e2101472f'), 'TERMINAL_JS': (465, '22baafe8044c1aa1f63f8f2cd983763f4b0c0b30db1f74a988f81f15f9cc7d6b')}
class Rejected(ValueError):pass
def require(v,msg):
 if not v:raise Rejected(msg)
def digest(data):return hashlib.sha256(data).hexdigest()
def read(p,maximum):
 p=pathlib.Path(p);require(not p.is_symlink() and p.is_file(),'MISSING_OR_NONREGULAR_FILE');require(p.stat().st_size<=maximum,'OVERSIZE_FILE');d=p.read_bytes();require(len(d)<=maximum,'OVERSIZE_FILE');return d
def rows(selected="application"):
 size,sha,name=(APP_BYTES,APP_SHA,"application.bin") if selected=="application" else (ROLLBACK_BYTES,ROLLBACK_SHA,"rollback-application.bin")
 return [dict(role=role,file=name,offset=offset,bytes=size,sha256=sha,partition_bytes=0x740000,erase_start=offset,erase_end_exclusive=offset+((size+4095)//4096)*4096,selected_for_execution=False) for role,offset in [('app0',0x10000),('app1',0x750000)]]
def check_rows(actual,selected="application"):
 require(actual==rows(selected),'UNREVIEWED_WRITE_OR_ERASE_RANGE')
 for r in actual:
  require(r['offset']+r['bytes']<=r['offset']+r['partition_bytes'],'IMAGE_EXCEEDS_SLOT')
  require(r['erase_end_exclusive']<=r['offset']+r['partition_bytes'],'ERASE_EXCEEDS_SLOT')
  for name,_,_,start,size in LAYOUT:
   if name not in ('app0','app1'):require(r['erase_end_exclusive']<=start or r['erase_start']>=start+size,'PROTECTED_DATA_OVERLAP')
 require(actual[0]['erase_end_exclusive']<=actual[1]['erase_start'],'OVERLAPPING_ERASES')
def image(data,size=APP_BYTES,sha=APP_SHA):
 # Same bounded segment/checksum format as tools/deployment_preflight.py esp_image.
 require(len(data)==size and digest(data)==sha,'WRONG_APPLICATION_BYTES')
 require(data[0]==0xe9 and 1<=data[1]<=16 and data[2]==2 and data[3]==0x4f and struct.unpack_from('<H',data,12)[0]==9 and data[23]==1,'WRONG_S3_16M_DIO80_HEADER')
 pos=24;checksum=0xef
 for _ in range(data[1]):
  require(pos+8<=len(data),'TRUNCATED_IMAGE');length=struct.unpack_from('<I',data,pos+4)[0];pos+=8;require(length<=len(data)-pos,'INVALID_SEGMENT')
  for b in data[pos:pos+length]:checksum^=b
  pos+=length
 end=(pos//16+1)*16
 require(end+32==len(data) and data[end-1]==checksum,'WRONG_IMAGE_CHECKSUM_OR_LENGTH');require(hashlib.sha256(data[:end]).digest()==data[end:],'WRONG_APPENDED_DIGEST')
def table(data,tool):
 require(len(data) in (3072,4096),'WRONG_TABLE_SIZE')
 if len(data)==4096:require(data[3072:]==b'\xff'*1024,'UNREVIEWED_TABLE_TRAILER')
 require(digest(data[:3072])==TABLE_SHA,'WRONG_INSTALLED_LAYOUT')
 t=tool.PartitionTable.from_binary(data[:3072]);t.verify();require([(p.name,p.type,p.subtype,p.offset,p.size) for p in t]==LAYOUT and all(not p.readonly and not p.encrypted for p in t),'WRONG_PARTITION_GEOMETRY_OR_FLAGS')
def ota(data):
 # Intentionally narrow supported state, NOT a general active-slot decoder.
 require(len(data)==8192 and digest(data)==OTA_SHA,'UNREVIEWED_OTA_STATE_REQUIRES_SEPARATE_REVIEW')
 require(struct.unpack_from('<I',data)[0]==1 and struct.unpack_from('<I',data,24)[0]==0xffffffff and struct.unpack_from('<I',data,28)[0]==zlib.crc32(data[:4],0xffffffff),'INVALID_OTA_RECORD')
 require(struct.unpack_from('<I',data,4096)[0]==0 and struct.unpack_from('<I',data,4124)[0]==0xffffffff,'UNREVIEWED_SECOND_OTA_RECORD')

SUPPORT=set(['APACHE-2.0.txt', 'DS01_STATEMENTS.txt', 'DS02_DELAY_STOP.txt', 'DS03_RECOVERY.txt', 'DS04_REJECT.txt', 'FIXTURE-SHA256.txt', 'INSTALL-MAC.md', 'OWNER-CHECK.md', 'README.md', 'RETURN-WORKING.md', 'ROLLBACK-MAC.md', 'build-inputs.json', 'gen_esp32part.py', 'independent-gate-result.json', 'independent-gate-summary.json', 'independent-layout.json', 'independent-release-receipt.json', 'independent-stack.json', 'independent-target-receipt.json', 'install-macos.sh', 'installer.py', 'original-build-report.json', 'post-build-attestation.json', 'preflight.py', 'rollback-build-receipt.json', 'rollback-macos.sh', 'source-LICENSE.txt', 'working-define-labels-macos-review-v1.zip'])

"""New receipt provider for frozen admission image/layout/OTA/installer guards.

This body is combined with the exact pinned parent primitives and CLI. Python
3.8 standard library only. No compilation, process, network or device interface.
"""

def validate_evidence(d,m):
 require(m.get('firmware_build_id')=='ROUTEB-DEFINE-STATEMENTS-H1-v1' and m.get('firmware_source_commit')==RELEASE['firmware_source_commit'],'WRONG_FIRMWARE_IDENTITY')
 require(m.get('status_label')=='REVIEW CANDIDATE / NOT INSTALLED' and m.get('historical_gate')=='BLOCKED / EXACT HISTORICAL INPUT UNAVAILABLE','WRONG_GATE_LABEL')
 require(m.get('independent_gate')=='DEFINE-CANDIDATE-INDEPENDENT-v1' and m.get('verification_source_commit')==RELEASE['verification_source_commit'],'WRONG_VERIFICATION_IDENTITY')
 require(m.get('physical_candidate_tested') is False and m.get('official_runtime_encoding_verified') is False,'UNSUPPORTED_PHYSICAL_OR_ENCODING_CLAIM')
 for name,expected in RELEASE['pins'].items():require(digest(read(d/name,4*1024*1024))==expected,'FROZEN_SUPPORT_BINDING_FAILED:'+name)
 summary=json.loads(read(d/'independent-gate-summary.json',4*1024*1024));gate=json.loads(read(d/'independent-gate-result.json',4*1024*1024))
 require(summary.get('status')==gate.get('status')=='INDEPENDENT ARTIFACT GATE PASS / NOT INSTALLED','WRONG_INDEPENDENT_GATE_STATUS')
 require(gate.get('policy')=='DEFINE-CANDIDATE-INDEPENDENT-v1' and all(gate.get('stages',{}).get(n)=='PASS' for n in ['layout','bounded_self_call','target','six_frozen_layers']),'INCOMPLETE_INDEPENDENT_GATE')
 require(summary.get('original_historical_gate')==gate.get('original_result')=='BLOCKED / EXACT HISTORICAL INPUT UNAVAILABLE','WRONG_HISTORICAL_GATE_LABEL')
 require(gate.get('firmware_compilation_attempts')==1 and gate.get('auxiliary_compiler_invocations')==2 and gate.get('artifacts_unchanged') is True,'WRONG_BUILD_COUNTS_OR_MUTATION')
 require(summary.get('firmware_compilation_attempts')==1 and summary.get('auxiliary_compiler_invocations')==2,'WRONG_SUMMARY_COUNTS')
 original=json.loads(read(d/'original-build-report.json',4*1024*1024));release=json.loads(read(d/'independent-release-receipt.json',4*1024*1024));target=json.loads(read(d/'independent-target-receipt.json',4*1024*1024));att=json.loads(read(d/'post-build-attestation.json',4*1024*1024))
 inputs_data=read(d/'build-inputs.json',1024*1024);inputs=json.loads(inputs_data);outer=digest(inputs_data);inner=digest(json.dumps(inputs['files'],sort_keys=True,separators=(',',':')).encode())
 require(inputs.get('source_commit')==RELEASE['firmware_source_commit'] and inputs.get('source_commit_contains_changes') is True and inputs.get('uncommitted_local_changes') is False,'WRONG_ORIGINAL_INPUT_PROVENANCE')
 require(outer==RELEASE['build_inputs_sha256']==att.get('build_inputs_sha256') and inner==inputs.get('files_sha256')==att.get('files_sha256'),'MANIFEST_INVENTORY_ATTESTATION_MISMATCH')
 require(att.get('kind')=='POST_BUILD_INDEPENDENT_ATTESTATION' and att.get('produced_by_original_builder') is False and att.get('source_commit')==RELEASE['firmware_source_commit'],'WRONG_ATTESTATION_PROVENANCE')
 identity=summary['identities'];vp=att['verification_provenance'];require(vp.get('build_source_commit')==RELEASE['firmware_source_commit'],'CONFLATED_BUILD_VERIFIER_PROVENANCE')
 require(digest(json.dumps(vp['verifier_files'],sort_keys=True,separators=(',',':')).encode())==vp.get('verifier_identity_sha256')==identity.get('independent_verifier_identity_sha256')==RELEASE['verifier_identity_sha256'],'WRONG_VERIFIER_IDENTITY')
 att_sha=digest(read(d/'post-build-attestation.json',4*1024*1024));require(att_sha==identity.get('supplementary_attestation_file_sha256')==gate['supplementary_attestation']['sha256'],'WRONG_ATTESTATION_IDENTITY')
 require(gate['supplementary_attestation'].get('produced_by_original_builder') is False,'FABRICATED_BUILDER_ATTESTATION')
 require(original['report']['application_sha256']==release['report']['application_sha256']==target['application_sha256']==APP_SHA and original['provenance']['elf_sha256']==release['provenance']['elf_sha256']==target['elf_sha256']==RELEASE['elf_sha256'],'WRONG_ARTIFACT_RECEIPT_BINDING')
 require(original['source_inventory']==release['source_inventory'],'ORIGINAL_SOURCE_RECORD_CHANGED')
 require(release['actual_runtime_build_id']==target['build_id']==ACTUAL_BUILD_ID,'WRONG_RUNTIME_IDENTITY')
 info=release['usb_observer_release_verification'];require(info.get('status')=='PASS' and info.get('full_frozen_h1_chain_executed') is True and info.get('assertions_preserved')==190 and info.get('assertions_removed')==0,'INCOMPLETE_FROZEN_RELEASE_CHAIN')
 require(info['usb_observer_target_binding']==target==att['usb_observer_target_binding'],'WRONG_TARGET_ATTESTATION_BINDING')
 require(release['admission_diagnostics_release_verification'].get('status')=='PASS' and info.get('recompiled') is False and info.get('target_source_or_images_modified') is False,'INCOMPLETE_OUTER_RELEASE')
 require(target['committed_source_provenance']['source_commit']==RELEASE['firmware_source_commit'] and target['build_inputs_sha256']==outer,'WRONG_TARGET_BUILD_SOURCE')
 require(target['define_labels']['workspace_bytes']==4096 and target['define_labels']['target_compiler_bytes']==3928 and target['define_labels']['constant_slots']==16 and target['define_labels']['max_label_bytes']==31,'WRONG_CAPACITY_PROOF')
 require(target['usb_observer']['state_plus_callback_bytes']<=2048 and target['usb_observer']['classification']=='UNKNOWN','WRONG_OBSERVER_RESOURCE_OR_CLASSIFIER_CLAIM')
 require(target['admission_diagnostics']['status']=='PASS' and target['admission_diagnostics']['compiler_workspace_bytes']==4096,'WRONG_ADMISSION_PROOF')
 inventory=original['source_inventory'];require(len(inventory)==201 and len({r['file'] for r in inventory})==201,'WRONG_SOURCE_INVENTORY')
 require(next(r['sha256'] for r in inventory if r['file']=='EvilDuckS3/core.cpp')==RELEASE['core_sha256'],'WRONG_DEFINE_OVERLAY')
 require(m.get('runtime_peak_stack_measured') is False and m.get('hardware_acceptance')=='PENDING','UNSUPPORTED_STACK_OR_HARDWARE_CLAIM')
 require(original['report']['ota_slot_bytes']==0x740000 and original['report']['static_ram_bytes']==115400,'WRONG_RESOURCE_IDENTITY')

def validate(directory,installed_table=None,installed_ota=None,require_installed=False,selected="application"):
 require(RELEASE is not None,'RELEASE_NOT_BOUND')
 require(selected in ("application","rollback"),"UNKNOWN_IMAGE_SELECTION")
 d=pathlib.Path(directory);m=json.loads(read(d/'manifest.json',1024*1024));require(m.get('package_id')=='evilduck-routeb-define-statements-h1-v1-independent-owner-review-v1' and m.get('source_commit')==SOURCE and m.get('installation_authorized') is False and m.get('update_method')=='FUTURE_ROM_APP_ONLY_BOTH_SLOTS','WRONG_PACKAGE_IDENTITY')
 require(m.get('application_bytes')==APP_BYTES and m.get('application_sha256')==APP_SHA and m.get('table_sha256')==TABLE_SHA,'WRONG_DECLARED_ARTIFACT_IDENTITY')
 check_rows(m['proposed_writes']);check_rows(m['rollback_writes'],'rollback');require(m.get('rollback_bytes')==ROLLBACK_BYTES and m.get('rollback_sha256')==ROLLBACK_SHA,'WRONG_ROLLBACK_IDENTITY');require(set(m['support_files'])==SUPPORT,'WRONG_SUPPORT_INVENTORY')
 expected=SUPPORT|{'manifest.json','application.bin','expected-partitions.bin','rollback-application.bin'}
 require({p.name for p in d.iterdir()}==expected and all(p.is_file() and not p.is_symlink() for p in d.iterdir()),'UNEXPECTED_PACKAGE_CONTENT')
 for n,r in m['support_files'].items():
  b=read(d/n,4*1024*1024);require(len(b)==r['bytes'] and digest(b)==r['sha256'],'SUPPORT_INTEGRITY_FAILED')
 image(read(d/'application.bin',APP_BYTES));image(read(d/'rollback-application.bin',ROLLBACK_BYTES),ROLLBACK_BYTES,ROLLBACK_SHA)
 spec=importlib.util.spec_from_file_location('pinned_partition_tool',d/'gen_esp32part.py');tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool);tool.offset_part_table=0x8000
 table(read(d/'expected-partitions.bin',4096),tool)
 validate_evidence(d,m)
 # Working return is an exact original reviewed kit, not a relabelled old rollback.
 require(m.get('working_firmware_return')==WORKING_RETURN,'WRONG_WORKING_RETURN_IDENTITY')
 working=read(d/WORKING_ZIP_FILE,WORKING_ZIP_BYTES)
 require(len(working)==WORKING_ZIP_BYTES and digest(working)==WORKING_ZIP_SHA,'WRONG_WORKING_RETURN_ZIP')
 with zipfile.ZipFile(io.BytesIO(working)) as return_zip:
  require(return_zip.testzip() is None and len(return_zip.infolist())==50,'INVALID_WORKING_RETURN_ARCHIVE')
  for item in return_zip.infolist():
   selected_path=pathlib.PurePosixPath(item.filename)
   require(not selected_path.is_absolute() and '..' not in selected_path.parts and not stat.S_ISLNK(item.external_attr>>16),'UNSAFE_WORKING_RETURN_ARCHIVE')
  return_manifest=json.loads(return_zip.read('manifest.json'))
  require(return_manifest.get('firmware_build_id')=='ROUTEB-DEFINE-LABELS-H1-v1','WRONG_WORKING_RETURN_BUILD_ID')
  working_app=return_zip.read('application.bin');working_rollback=return_zip.read('rollback-application.bin')
  require(len(working_app)==WORKING_APP_BYTES and digest(working_app)==WORKING_APP_SHA,'WRONG_WORKING_RETURN_APPLICATION')
  require(len(working_rollback)==ROLLBACK_BYTES and digest(working_rollback)==ROLLBACK_SHA,'WRONG_WORKING_RETURN_OLDER_ROLLBACK')
  for name in ['preflight.py','installer.py','install-macos.sh','rollback-macos.sh','INSTALL-MAC.md']:
   contents=return_zip.read(name);declared=return_manifest['support_files'][name]
   require(len(contents)==declared['bytes'] and digest(contents)==declared['sha256'],'WRONG_WORKING_RETURN_HELPER')
 rollback_receipt=json.loads(read(d/'rollback-build-receipt.json',4*1024*1024));require(rollback_receipt['report']['application_sha256']==ROLLBACK_SHA and rollback_receipt['report']['application_bytes']==ROLLBACK_BYTES,'WRONG_ROLLBACK_RECEIPT')
 out=dict(selected_image=selected,plan_ready=False,package_integrity='PASS',source_commit=SOURCE,application_sha256=APP_SHA,installed_metadata='NOT_SUPPLIED',selected_write_ranges=[],installation_authorized=False,hardware_access=False,device_authenticity_or_freshness_verified=False)
 require(not require_installed or (installed_table is not None and installed_ota is not None),'CURRENT_INSTALLED_METADATA_REQUIRED')
 require((installed_table is None)==(installed_ota is None),'BOTH_INSTALLED_METADATA_FILES_REQUIRED')
 if installed_table is not None:
  table(read(installed_table,4096),tool);ota(read(installed_ota,8192));out.update(installed_metadata='SUPPLIED_FILES_MATCH_SUPPORTED_LAYOUT_AND_APP0_INITIALIZER',plan_ready=True,selected_write_ranges=rows(selected),boot_selection_from_supplied_metadata='app0',metadata_provenance='OWNER_LOCAL_FILES_NOT_AUTHENTICATED_DEVICE_READ')
 return out
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',type=pathlib.Path,required=True);p.add_argument('--installed-table',type=pathlib.Path);p.add_argument('--installed-otadata',type=pathlib.Path);p.add_argument("--require-installed",action="store_true");p.add_argument("--image",choices=["application","rollback"],default="application");a=p.parse_args()
 try:print(json.dumps(validate(a.directory,a.installed_table,a.installed_otadata,a.require_installed,a.image),indent=2));return 0
 except (OSError,ValueError,KeyError,AssertionError) as e:
  print(json.dumps(dict(package_integrity='REJECTED',reason=str(e) if isinstance(e,Rejected) else 'INVALID_OR_MISSING_INPUT',installation_authorized=False,hardware_access=False)));return 1
if __name__=='__main__':raise SystemExit(main())
