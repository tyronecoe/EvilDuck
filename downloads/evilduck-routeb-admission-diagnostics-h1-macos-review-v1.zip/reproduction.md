REVIEW CANDIDATE - NOT INSTALLED - NOT OWNER-HARDWARE-VERIFIED.

This release corrects Route B source-admission error ownership and physical-line reporting. It adds no OS detector, USB profile, new language feature or automatic payload. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: ROUTEB-ADMISSION-DIAGNOSTICS-H1-v1. Application: 1450944 bytes; SHA-256 fce91bca0774181a1be6bc691a1303d47f61caba49e979e89bfa678ef41f60f1. Firmware checkpoint: c9fd36c3e03b2d7ffa318b289398ff7dc1c9fd44. These are artifact identities, not installed-device readback.

The actual target application/ELF, source inventory, approved dependency profile, committed inputs and complete inherited 190-assert release chain are bound in build-receipt.json/source-attestation.json. No post-build verifier-only delta is allowed. Fresh admission checks and pre-fix negative controls are identified separately from unchanged historical/native/web receipts. All software uses mocks; no physical USB acceptance, installed-byte attestation or macOS runtime claim is made.

First offline check, with EvilDuck UNPLUGGED, from the newly extracted directory:

    python3 preflight.py --directory .

Expect package_integrity PASS, plan_ready false, empty selected_write_ranges, installed_metadata NOT_SUPPLIED, hardware_access false and installation_authorized false. No serial/network/device access or installer dispatch occurs in that check.

