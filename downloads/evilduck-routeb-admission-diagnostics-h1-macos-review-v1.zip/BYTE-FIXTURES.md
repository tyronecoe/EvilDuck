REVIEW CANDIDATE - NOT INSTALLED - NOT OWNER-HARDWARE-VERIFIED.

This release corrects Route B source-admission error ownership and physical-line reporting. It adds no OS detector, USB profile, new language feature or automatic payload. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: ROUTEB-ADMISSION-DIAGNOSTICS-H1-v1. Application: 1450944 bytes; SHA-256 fce91bca0774181a1be6bc691a1303d47f61caba49e979e89bfa678ef41f60f1. Firmware checkpoint: c9fd36c3e03b2d7ffa318b289398ff7dc1c9fd44. These are artifact identities, not installed-device readback.

BYTE-PRESERVING SOURCE SAVE/READBACK - LATER OWNER STEP ONLY

The package and preflight do not contact EvilDuck. Never paste, edit or resave AD01_INVALID_BYTE_LINE3.duck. The file intentionally contains UTF-8 bytes C3 A9 on physical line 3; Route B rejects them as unsupported source encoding.

1. Keep execution idle. Verify each original local file against FIXTURE-SHA256.txt. Use a fresh safe filename; GET /script?s=AD01_INVALID_BYTE_LINE3.duck must report 404 before saving. Stop if it already exists: do not overwrite an owner file.
2. Save with the existing HTTP POST /script endpoint, header X-Duck-Password (entered privately, never in URL/logs), Content-Type application/x-www-form-urlencoded. The two fields are name=AD01_INVALID_BYTE_LINE3.duck and content=<the exact file bytes>. Percent-encode the original bytes; do not decode/re-encode or normalize newlines. The invalid pair must encode as %C3%A9 and CRLF as %0D%0A. The raw /upload endpoint is disabled and must not be used.
3. Read back through authenticated GET /script?s=AD01_INVALID_BYTE_LINE3.duck. Save the response bytes locally and require an exact byte comparison AND matching SHA-256 against the original. HTTP status alone is insufficient. If saving refuses bytes or the readback differs, stop this optional observation without bypassing validation.
4. Only after separate owner authorization and a matching readback, submit the stored source through explicit Route B: authenticated GET /run?engine=routeb&s=AD01_INVALID_BYTE_LINE3.duck or the established local console command routeb AD01_INVALID_BYTE_LINE3.duck. Record the real request ID, terminal Capability/Error, code 2, line 3 and blank TextEdit. Do not execute the file on the Mac as a shell/Python program.
5. AD02_VALID_RECOVERY.txt can use the ordinary editor/save path; then run Route B once, focus blank TextEdit during its five-second delay, and expect ADMISSION_OK plus newline and matching Completed status. These instructions never automatically submit a payload.
