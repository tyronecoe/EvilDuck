REVIEW CANDIDATE - NOT INSTALLED - NOT OWNER-HARDWARE-VERIFIED.

This release corrects Route B source-admission error ownership and physical-line reporting. It adds no OS detector, USB profile, new language feature or automatic payload. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: ROUTEB-ADMISSION-DIAGNOSTICS-H1-v1. Application: 1450944 bytes; SHA-256 fce91bca0774181a1be6bc691a1303d47f61caba49e979e89bfa678ef41f60f1. Firmware checkpoint: c9fd36c3e03b2d7ffa318b289398ff7dc1c9fd44. These are artifact identities, not installed-device readback.

First offline check, with EvilDuck UNPLUGGED, from the newly extracted directory:

    python3 preflight.py --directory .

Expect package_integrity PASS, plan_ready false, empty selected_write_ranges, installed_metadata NOT_SUPPLIED, hardware_access false and installation_authorized false. No serial/network/device access or installer dispatch occurs in that check.

The original observer-v2 capture remains capture-only and UNKNOWN: no new capture campaign or positive OS rule is introduced. Existing captures, contracts and old acceptance receipts are historical provenance, not a request to repeat DEL/DEFINE/H1/lock-wait tests. The last owner-reported running image before this candidate was observer v2. This package has not been physically accepted or installed by its preparer.

WORKING_DEFINE_RETURN is the unchanged nested working-define-labels-macos-review-v1.zip: 2,691,374 bytes, SHA-256 b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed. Its application is ROUTEB-DEFINE-LABELS-H1-v1, 1,438,048 bytes, SHA-256 167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30. Extract it separately, preflight unplugged, and follow its original guarded INSTALL-MAC.md procedure to return deliberately. The outer rollback-macos.sh selects older source/text-v2, NOT DEFINE. No automatic rollback, erase, format, settings reset or reboot occurs.

The exact older source/text-v2 rollback is 1,413,200 bytes, SHA-256 cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02. It lacks later privacy/dashboard fixes and is not a full-device/filesystem restore. The e825 editor candidate is not a known-good recovery image. Preserve every private backup.

Read OWNER-CHECK.md, INSTALL-MAC.md, RETURN-WORKING.md and FIXTURE-SHA256.txt.
