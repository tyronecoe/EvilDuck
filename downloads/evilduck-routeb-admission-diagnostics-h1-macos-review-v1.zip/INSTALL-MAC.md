REVIEW CANDIDATE - NOT INSTALLED - NOT OWNER-HARDWARE-VERIFIED.

This release corrects Route B source-admission error ownership and physical-line reporting. It adds no OS detector, USB profile, new language feature or automatic payload. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Build ID: ROUTEB-ADMISSION-DIAGNOSTICS-H1-v1. Application: 1450944 bytes; SHA-256 fce91bca0774181a1be6bc691a1303d47f61caba49e979e89bfa678ef41f60f1. Firmware checkpoint: c9fd36c3e03b2d7ffa318b289398ff7dc1c9fd44. These are artifact identities, not installed-device readback.

First offline check, with EvilDuck UNPLUGGED, from the newly extracted directory:

    python3 preflight.py --directory .

Expect package_integrity PASS, plan_ready false, empty selected_write_ranges, installed_metadata NOT_SUPPLIED, hardware_access false and installation_authorized false. No serial/network/device access or installer dispatch occurs in that check.

The actual target application/ELF, source inventory, approved dependency profile, committed inputs and complete inherited 190-assert release chain are bound in build-receipt.json/source-attestation.json. No post-build verifier-only delta is allowed. Fresh admission checks and pre-fix negative controls are identified separately from unchanged historical/native/web receipts. All software uses mocks; no physical USB acceptance, installed-byte attestation or macOS runtime claim is made.

Host workflow: Intel macOS High Sierra 10.13.6, Bash 3.2, Python 3.8+ and preinstalled esptool 4.12. Do not install dependencies from this package. Hardware target: ESP32-S3, 16 MiB flash, PSRAM disabled. The unchanged installer refuses unsupported chip, security, partition and OTA states. It creates a new private full-flash backup before its final INSTALL confirmation (or ROLLBACK confirmation); the backup can contain credentials/scripts/settings and remains even if confirmation is declined. No existing backup is deleted or overwritten. Only the two application regions 0x10000 and 0x750000 can be written; bootloader, partition table, NVS, OTA metadata and filesystems are excluded. No automatic reboot or retry.

The following are later deliberate OWNER operations, not the offline check. Enter ROM mode using the original instructions and rediscover /dev/cu.usbmodem* after reconnecting. Replace CURRENT_PORT with the verified current port; never run the placeholder literally.

    bash install-macos.sh --action check --port CURRENT_PORT
    bash install-macos.sh --action install --port CURRENT_PORT

Deliberate older rollback:

    bash rollback-macos.sh --port CURRENT_PORT

The source-stage label ROUTEB-RIGHT-MODIFIERS-H1-EXPERIMENTAL-v1 is historical provenance, not this candidate build ID.

WORKING_DEFINE_RETURN is the unchanged nested working-define-labels-macos-review-v1.zip: 2,691,374 bytes, SHA-256 b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed. Its application is ROUTEB-DEFINE-LABELS-H1-v1, 1,438,048 bytes, SHA-256 167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30. Extract it separately, preflight unplugged, and follow its original guarded INSTALL-MAC.md procedure to return deliberately. The outer rollback-macos.sh selects older source/text-v2, NOT DEFINE. No automatic rollback, erase, format, settings reset or reboot occurs.

The exact older source/text-v2 rollback is 1,413,200 bytes, SHA-256 cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02. It lacks later privacy/dashboard fixes and is not a full-device/filesystem restore. The e825 editor candidate is not a known-good recovery image. Preserve every private backup.

