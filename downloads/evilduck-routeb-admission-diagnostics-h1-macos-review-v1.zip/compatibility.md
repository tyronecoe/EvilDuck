REVIEW CANDIDATE - NOT INSTALLED - NOT OWNER-HARDWARE-VERIFIED.

This release corrects Route B source-admission error ownership and physical-line reporting. It adds no OS detector, USB profile, new language feature or automatic payload. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

Grammar, source acceptance, BOM rules, raw identity, compiler/runtime budgets, keyboard reports, STOP/cleanup, privacy, EDR1 and H1 are unchanged. Only current-request source-admission diagnostics are corrected.

The original observer-v2 capture remains capture-only and UNKNOWN: no new capture campaign or positive OS rule is introduced. Existing captures, contracts and old acceptance receipts are historical provenance, not a request to repeat DEL/DEFINE/H1/lock-wait tests. The last owner-reported running image before this candidate was observer v2. This package has not been physically accepted or installed by its preparer.

