REVIEW CANDIDATE - NOT INSTALLED - NOT OWNER-HARDWARE-VERIFIED.

This release corrects Route B source-admission error ownership and physical-line reporting. It adds no OS detector, USB profile, new language feature or automatic payload. H1 remains opt-in and experimental; canonical Hak5 numeric encoding is unresolved.

WORKING_DEFINE_RETURN is the unchanged nested working-define-labels-macos-review-v1.zip: 2,691,374 bytes, SHA-256 b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed. Its application is ROUTEB-DEFINE-LABELS-H1-v1, 1,438,048 bytes, SHA-256 167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30. Extract it separately, preflight unplugged, and follow its original guarded INSTALL-MAC.md procedure to return deliberately. The outer rollback-macos.sh selects older source/text-v2, NOT DEFINE. No automatic rollback, erase, format, settings reset or reboot occurs.

First offline check, with EvilDuck UNPLUGGED, from the newly extracted directory:

    python3 preflight.py --directory .

Expect package_integrity PASS, plan_ready false, empty selected_write_ranges, installed_metadata NOT_SUPPLIED, hardware_access false and installation_authorized false. No serial/network/device access or installer dispatch occurs in that check.

Host workflow: Intel macOS High Sierra 10.13.6, Bash 3.2, Python 3.8+ and preinstalled esptool 4.12. Do not install dependencies from this package. Hardware target: ESP32-S3, 16 MiB flash, PSRAM disabled. The unchanged installer refuses unsupported chip, security, partition and OTA states. It creates a new private full-flash backup before its final INSTALL confirmation (or ROLLBACK confirmation); the backup can contain credentials/scripts/settings and remains even if confirmation is declined. No existing backup is deleted or overwritten. Only the two application regions 0x10000 and 0x750000 can be written; bootloader, partition table, NVS, OTA metadata and filesystems are excluded. No automatic reboot or retry.

The exact older source/text-v2 rollback is 1,413,200 bytes, SHA-256 cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02. It lacks later privacy/dashboard fixes and is not a full-device/filesystem restore. The e825 editor candidate is not a known-good recovery image. Preserve every private backup.

