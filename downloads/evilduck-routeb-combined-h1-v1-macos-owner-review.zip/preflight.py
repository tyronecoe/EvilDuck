# Admission diagnostics additive preflight over immutable observer-v2 parent SHA256 232ef2673fcc9e29082c13c5d3c52412369f4f656c663e0a70ec9c209a994ee0
# Observer v2 additive package; immutable v1 parent SHA256 c5e8384ee40653c5b017685ce81431bc7eca4718e1a8f8b5c864ab86aff37a47
# USB enumeration observer capture package over immutable DEFINE parent 5fbe1fa388759810f40bceeb2dbaa3d16efe633352364ec4ae550ddd12fecfd7
# Bounded DEFINE-label package over immutable DEL parent 241b40e3f8284615cca8bd870022754039024a3d4d5e8316535fac5118f3b50d
# Additive DEL-alias review package; immutable REPEAT parent d095130bfb73d75ab708be338df97739227f129cecfe2a4fb60226a94f71ab29
# Bounded REPEAT preflight: inherited image/layout/OTA/installer boundaries unchanged.
# Original image/layout/OTA/read-only functions and rollback tail retained unchanged.
# Dashboard cleanup additive preflight over immutable Privacy Fix 1 parent.
# Parent SHA-256: 6b27aeeaba35346ee68da840e8d3438fe0eca34b14bb61d26a9d96ce10cf1b44
# Historical H1/source-layer identities stay historical; final dashboard identity is distinct.
# Privacy Fix 1 additive package preflight. Historical H1 parent SHA256 b8de87a5b63237e5400f95e1bfb05e54aa05f3add5d4c309d2964b09b80ce79f
# Only package identity/support inventory and additional privacy provenance checks differ.
# Additive right-side modifier package preflight; parent SHA256 5ef335b22921bd3d90fcd9b6441081a538dc635067713e727dadbf5030e0f8a6
# Additive H1 package preflight; parent SHA256 8c6d10b6e2193fe625fb86ca191c09e9f0f259d87f27535a8a0d48b940fff49b
# Additive bounded-lock-wait adaptation of tests/source_text_v2/preflight.py
# Parent SHA-256: 889d4115478b06435a1efca1915581ac002bc82c51b4258c77c280415ea03b72
# Additive source/text-portability adaptation of tests/payload_restart/preflight.py
# Parent SHA-256: 09bdecd1f57a823a3c92db8f9e879981fc6f2fbbe3bc32baac0c36a6600a5418
# Additive payload-restart adaptation of tests/text_keyboard/preflight.py
# Parent SHA-256: 65afceff0e42457238c47584b5df36e0b76b2bdd58340977b3a3aff011918778
# Additive release adaptation; historical lock-feedback preflight remains unchanged.
#!/usr/bin/env python3
"""Read-only, Python3.8+ package/layout checks. No device, serial, network or write API."""
import argparse, hashlib, importlib.util, io, json, pathlib, stat, struct, sys, zipfile, zlib
sys.dont_write_bytecode=True
RELEASE={'source_commit': 'c2b6fa35d6a50609bd9b4c59409e1aa2f1b417e8', 'firmware_source_commit': 'c2b6fa35d6a50609bd9b4c59409e1aa2f1b417e8', 'application_bytes': 1451200, 'application_sha256': 'dd1c6e8fd5725749da0605707ae86b29611366ca9433237a5de1c7f368ddbeb6', 'support': ['APACHE-2.0.txt', 'OWNER-CHECK.md', 'README.md', 'RECOVERY-ROLES.md', 'build-inputs.json', 'final-verification-receipt.json', 'gen_esp32part.py', 'install-macos.sh', 'installer.py', 'linked-release-receipt.json', 'linked-target-receipt.json', 'original-build-report.json', 'original-target-failure.json', 'post-build-attestation.json', 'preflight.py', 'prior-define-statements-application.bin', 'rollback-build-receipt.json', 'rollback-macos.sh', 'source-LICENSE.txt', 'working-define-labels-macos-review-v1.zip'], 'pins': {'APACHE-2.0.txt': 'cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30', 'OWNER-CHECK.md': 'bebf6a76e8a297a6040baf4e8d3046cf840b3458f16bdfdef0774b9302f463ca', 'README.md': '08843c2e31a7c28d48113c54102f6bc2c22397edf6667bdc0143b6cdfb007df3', 'RECOVERY-ROLES.md': 'dcb08830074441508d68c5f12ed0e9f2cb827033b85814593310c29e2955e883', 'build-inputs.json': '76a26b7a4b95e16b27bc88a0ec23ab680628d0a17558c3c60a586fb2561fbde3', 'final-verification-receipt.json': '2b7648560a84f958940141a4ee20681206755ff00a97f7010092bc0fe32b62a5', 'gen_esp32part.py': 'b82195fe2ff6b0841a8c8927e07cc90efc31695168f4c6b776194fa9b4f2950c', 'install-macos.sh': '290467849471980640fcf4bd6e44d69e22ec20f1cb7f5fd4436c0dc8a83f1cd8', 'installer.py': '8fa33856680df3cb492a2c58bc1db92a809bad8aef6ccdc1d5a09212ae7a4a87', 'linked-release-receipt.json': '318634d4c1920c7d81e23b59c45689d42729dc807d83e3542552170b814756d0', 'linked-target-receipt.json': '3e23cc1acf5621c086d98c4e87192a8778378c9e1ec56069e933418d627f4df4', 'original-build-report.json': '482e6b855499f17aa25b15600091028aa89dadf4c86fb4c709f77df4ab897b96', 'original-target-failure.json': '4f2f758fdc6562a95e9a58f6faa96875cea7c1b6452188e294b50bcb8d9f5e8b', 'post-build-attestation.json': 'f4741fc72a07917703dbc81b3ee0a99cf29b2fff73b43b23fbc3cb152555eb25', 'prior-define-statements-application.bin': '524805fbde1af49b908b156e0eb50de48393b8e2810efcf0eaddba931408012e', 'rollback-build-receipt.json': 'fc179a97b8a1768ee85161f4c6a80e648a1b96652bfd698e91d26717edf59953', 'rollback-macos.sh': '6ad97fa1d58d89689e2638ec1559c2b927e7251cb99047bdb003ff3cea97321b', 'source-LICENSE.txt': 'b81f3e122b91e521ffe58c1a983d9551cc71b7f3f840c22499bda69bfd500ddb', 'working-define-labels-macos-review-v1.zip': 'b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed'}, 'verification_source_commit': '08227890083e654e803d61d416672042c55a6539', 'elf_sha256': '169704b3ece7a3f5650098d650ce4c0e324b267496a4b3293c68ed4118c51122', 'map_sha256': 'b7d732e995d570ce98499296fca58391ce7479905c54d5a6a1146d3d0a5b7e60'}
# The public package replaces only RELEASE with its exact generated identity.
SOURCE=RELEASE['source_commit'] if RELEASE else None
APP_BYTES=RELEASE['application_bytes'] if RELEASE else 0
APP_SHA=RELEASE['application_sha256'] if RELEASE else None
ROLLBACK_BYTES=1413200
ROLLBACK_SHA='cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02'
TABLE_SHA='b79bde9ef4a9544411d97a31a1d326b2028213269ad0dcc643ea921230ce3d5e'
OTA_SHA='f94c5d786a7a8fab06ac5d10e33bf37711a6697636dc037559ea19cc410a17f0'
LAYOUT=[('nvs',1,2,0x9000,0x5000),('otadata',1,0,0xe000,0x2000),('app0',0,0x10,0x10000,0x740000),('app1',0,0x11,0x750000,0x740000),('spiffs',1,0x82,0xe90000,0x160000),('coredump',1,3,0xff0000,0x10000)]
SUPPORT={'README.md','OWNER-CHECK.md','INSTALL-MAC.md','ROLLBACK-MAC.md','preflight.py','installer.py','install-macos.sh','rollback-macos.sh','gen_esp32part.py','APACHE-2.0.txt','source-LICENSE.txt','build-receipt.json','rollback-build-receipt.json','firmware-report.md','test-results.json','compatibility.md','owner-evidence.md','source-manifest.json','dependency-pin.json','reproduction.md','rm-shift.txt','rm-modifier-taps.txt','rm-stop.txt','rm-malformed.txt','privacy-source-manifest.json','dashboard-source-manifest.json','reviewed-editor-source-manifest.json','editor-build-source-manifest.json','build-inputs.json','source-attestation.json','response-source-manifest.json','static-response-build-source-manifest.json','previous-repeat-source-manifest.json','previous-repeat-release-source-manifest.json','native-test-receipt.json','web-test-receipt.json','current-del-regression-receipt.json','current-define-regression-receipt.json','del-source-manifest.json','del-release-source-manifest.json','del-test-receipt.json','define-source-manifest.json','define-release-source-manifest.json','define-test-receipt.json','del-owner-closeout.md','D01_DEFINE_27.txt','D02_DEFINE_31.txt','D03_DEFINE_32_Rejected.txt','observer-source-manifest.json','observer-web-source-manifest.json','observer-release-source-manifest.json','observer-v2-source-manifest.json','observer-v2-web-source-manifest.json','observer-v2-release-source-manifest.json','observer-test-receipt.json','observer-web-test-receipt.json','CAPTURE-CONTRACT.md','evidence-gate.json','observer-v1-export-0.json','observer-v1-export-1.json','observer-v1-export-2.json','observer-v1-export-3.json','observer-v1-export-4.json','observer-v1-owner-handoff.txt','define-owner-acceptance.md','working-define-labels-macos-review-v1.zip','RETURN-WORKING.md'}
SUPPORT |= {'admission-source-manifest.json','admission-release-source-manifest.json','admission-test-receipt.json','admission-negative-controls.json','FIXTURE-SHA256.txt','AD00_PRIOR_COMPILE_LINE5.txt','AD01_INVALID_BYTE_LINE3.duck','AD02_VALID_RECOVERY.txt','BYTE-FIXTURES.md'}
ACTUAL_BUILD_ID='ROUTEB-COMBINED-H1-v1'
WORKING_ZIP_FILE='working-define-labels-macos-review-v1.zip'
WORKING_ZIP_BYTES=2691374
WORKING_ZIP_SHA='b91946bec818616f35a469edd6c2efa525eea01276d238b42ed1b26dea3558ed'
WORKING_APP_BYTES=1438048
WORKING_APP_SHA='167cf5013cd4aa7c0823e5c7391ca9f6d400b7b99df6fe0e46085048fde91a30'
WORKING_RETURN=dict(role='WORKING_DEFINE_RETURN',file=WORKING_ZIP_FILE,bytes=WORKING_ZIP_BYTES,sha256=WORKING_ZIP_SHA,build_id='ROUTEB-DEFINE-LABELS-H1-v1',application_bytes=WORKING_APP_BYTES,application_sha256=WORKING_APP_SHA,older_rollback_sha256=ROLLBACK_SHA,method='EXTRACT_SEPARATE_FOLDER_AND_USE_UNCHANGED_GUARDED_KIT')
EDITOR_BUILD_ID='ROUTEB-EDITOR-SAFETY-UNINSTALLED-v1'
ORIGINAL_BASE='805d989c3ac50cb96025862c95916830c59f8ba7'
SOURCE_CHECKPOINT=RELEASE['firmware_source_commit'] if RELEASE else None
EDITOR_HEADER_SHA='df10d10fd612ecb8be37c0c8e3a092720af463870814cab1c649e8a70304e445'
EXPECTED_RESOURCES={'INDEX_HTML': (13145, 'b12d84e89f88d1f9565192cebc940b79e4de0ee94b41f8ba186579843c571ed8'), 'INDEX_JS': (34649, 'd7fa4bcdf0d49f5770c09ffedd3515ddcbb6dbaad5f5a55091240d7c313e0cfa'), 'SETTINGS_HTML': (5390, 'f545e9154b2cf8d5e6573075008a87704a786bceb44fc625376b7a7d64bdd4e8'), 'SETTINGS_JS': (10503, '7ef1cc50fdbb772e7dedb2629c6004b744f5ef9b7a0e35f2abb7b93ceb2af686'), 'STYLE_CSS': (31976, '572d65a22ddb9892bea169a8ea43ca078e3aa9207519b7cd58cb465de39428da')}
EXPECTED_WIRE={'INDEX_HTML': (13144, '790a671f3feca307df39b200cdd4fd9ae27d0e8b4ca13d825328f25e400fe5eb'), 'SETTINGS_HTML': (5389, 'ef9f7093b2e537dc18ab2100bc03c9cbc6a7b9886291ace5c1fcfa12c5c1ce3a'), 'TERMINAL_HTML': (1324, 'cd341048c6d0a1211bd8ff0670203d706f0247eab8c72db08243d5529ba89d51'), 'CREDITS_HTML': (1746, '06d0f8e850c968b34a418d8b6462018811c0e7dd4d865f40c8c96644f87a2e8d'), 'ERROR404_HTML': (869, 'a8e89049a587a61fc7b2bcdd21ccedd578a4b1026df0e796be2a39108fc6da9d'), 'STYLE_CSS': (31975, '37df80940a89fb76e7373a1f1cadb687551b068cc94e65d61a18e03100cbed50'), 'INDEX_JS': (34648, '681192a3aa5474d4a313779ea9a661a2b234c73965f12030145bef7fbcf4409f'), 'SETTINGS_JS': (10502, '37cbfdbd4a4dafc50ec34c79fc862ec1c28ca69eb47d393d1f3d6e8e2101472f'), 'TERMINAL_JS': (465, '22baafe8044c1aa1f63f8f2cd983763f4b0c0b30db1f74a988f81f15f9cc7d6b')}
class Rejected(ValueError):pass
def require(v,msg):
 if not v:raise Rejected(msg)
def digest(data):return hashlib.sha256(data).hexdigest()
def read(p,maximum):
 p=pathlib.Path(p);require(not p.is_symlink() and p.is_file(),'MISSING_OR_NONREGULAR_FILE');require(p.stat().st_size<=maximum,'OVERSIZE_FILE');d=p.read_bytes();require(len(d)<=maximum,'OVERSIZE_FILE');return d
def rows(selected="application"):
 size,sha,name=(APP_BYTES,APP_SHA,"application.bin") if selected=="application" else (ROLLBACK_BYTES,ROLLBACK_SHA,"rollback-application.bin")
 return [dict(role=role,file=name,offset=offset,bytes=size,sha256=sha,partition_bytes=0x740000,erase_start=offset,erase_end_exclusive=offset+((size+4095)//4096)*4096,selected_for_execution=False) for role,offset in [('app0',0x10000),('app1',0x750000)]]
def check_rows(actual,selected="application"):
 require(actual==rows(selected),'UNREVIEWED_WRITE_OR_ERASE_RANGE')
 for r in actual:
  require(r['offset']+r['bytes']<=r['offset']+r['partition_bytes'],'IMAGE_EXCEEDS_SLOT')
  require(r['erase_end_exclusive']<=r['offset']+r['partition_bytes'],'ERASE_EXCEEDS_SLOT')
  for name,_,_,start,size in LAYOUT:
   if name not in ('app0','app1'):require(r['erase_end_exclusive']<=start or r['erase_start']>=start+size,'PROTECTED_DATA_OVERLAP')
 require(actual[0]['erase_end_exclusive']<=actual[1]['erase_start'],'OVERLAPPING_ERASES')
def image(data,size=APP_BYTES,sha=APP_SHA):
 # Same bounded segment/checksum format as tools/deployment_preflight.py esp_image.
 require(len(data)==size and digest(data)==sha,'WRONG_APPLICATION_BYTES')
 require(data[0]==0xe9 and 1<=data[1]<=16 and data[2]==2 and data[3]==0x4f and struct.unpack_from('<H',data,12)[0]==9 and data[23]==1,'WRONG_S3_16M_DIO80_HEADER')
 pos=24;checksum=0xef
 for _ in range(data[1]):
  require(pos+8<=len(data),'TRUNCATED_IMAGE');length=struct.unpack_from('<I',data,pos+4)[0];pos+=8;require(length<=len(data)-pos,'INVALID_SEGMENT')
  for b in data[pos:pos+length]:checksum^=b
  pos+=length
 end=(pos//16+1)*16
 require(end+32==len(data) and data[end-1]==checksum,'WRONG_IMAGE_CHECKSUM_OR_LENGTH');require(hashlib.sha256(data[:end]).digest()==data[end:],'WRONG_APPENDED_DIGEST')
def table(data,tool):
 require(len(data) in (3072,4096),'WRONG_TABLE_SIZE')
 if len(data)==4096:require(data[3072:]==b'\xff'*1024,'UNREVIEWED_TABLE_TRAILER')
 require(digest(data[:3072])==TABLE_SHA,'WRONG_INSTALLED_LAYOUT')
 t=tool.PartitionTable.from_binary(data[:3072]);t.verify();require([(p.name,p.type,p.subtype,p.offset,p.size) for p in t]==LAYOUT and all(not p.readonly and not p.encrypted for p in t),'WRONG_PARTITION_GEOMETRY_OR_FLAGS')
def ota(data):
 # Intentionally narrow supported state, NOT a general active-slot decoder.
 require(len(data)==8192 and digest(data)==OTA_SHA,'UNREVIEWED_OTA_STATE_REQUIRES_SEPARATE_REVIEW')
 require(struct.unpack_from('<I',data)[0]==1 and struct.unpack_from('<I',data,24)[0]==0xffffffff and struct.unpack_from('<I',data,28)[0]==zlib.crc32(data[:4],0xffffffff),'INVALID_OTA_RECORD')
 require(struct.unpack_from('<I',data,4096)[0]==0 and struct.unpack_from('<I',data,4124)[0]==0xffffffff,'UNREVIEWED_SECOND_OTA_RECORD')

SUPPORT=set(['APACHE-2.0.txt', 'OWNER-CHECK.md', 'README.md', 'RECOVERY-ROLES.md', 'build-inputs.json', 'final-verification-receipt.json', 'gen_esp32part.py', 'install-macos.sh', 'installer.py', 'linked-release-receipt.json', 'linked-target-receipt.json', 'original-build-report.json', 'original-target-failure.json', 'post-build-attestation.json', 'preflight.py', 'prior-define-statements-application.bin', 'rollback-build-receipt.json', 'rollback-macos.sh', 'source-LICENSE.txt', 'working-define-labels-macos-review-v1.zip'])

"""New receipt provider for frozen admission image/layout/OTA/installer guards.

This body is combined with the exact pinned parent primitives and CLI. Python
3.8 standard library only. No compilation, process, network or device interface.
"""

def validate_evidence(d,m):
 require(m.get('firmware_build_id')==ACTUAL_BUILD_ID and m.get('firmware_source_commit')==RELEASE['firmware_source_commit'],'WRONG_FIRMWARE_IDENTITY')
 require(m.get('verification_source_commit')==RELEASE['verification_source_commit'] and m.get('status_label')=='REVIEW CANDIDATE / NOT INSTALLED','WRONG_REVIEW_IDENTITY')
 require(m.get('independent_gate')=='COMBINED_TARGET_AND_RELEASE','WRONG_GATE_IDENTITY')
 require(m.get('physical_candidate_tested') is False and m.get('hardware') is False and m.get('hardware_acceptance')=='PENDING','WRONG_HARDWARE_CLAIM')
 for name,expected in RELEASE['pins'].items():
  require(digest(read(d/name,4*1024*1024))==expected,'SUPPORT_BINDING_FAILED:'+name)
 def receipt(name):
  return json.loads(read(d/name,4*1024*1024))
 final=receipt('final-verification-receipt.json')
 linked=receipt('linked-release-receipt.json')
 target=receipt('linked-target-receipt.json')
 attestation=receipt('post-build-attestation.json')
 original=receipt('original-build-report.json')
 inputs=read(d/'build-inputs.json',1024*1024)
 require(final['status']== 'VERIFICATION PASS' and final['build_id']==ACTUAL_BUILD_ID,'WRONG_FINAL_RESULT')
 require(final['source_commit']==attestation['source_commit']==json.loads(inputs)['source_commit']==SOURCE,'WRONG_SOURCE_IDENTITY')
 require(final['verifier_repair_commit']==attestation['repaired_verifier_commit']==RELEASE['verification_source_commit'],'WRONG_VERIFIER_REPAIR')
 evidence=final['evidence_sha256']
 for name,original_name in [('linked-target-receipt.json','linked-target.json'),('linked-release-receipt.json','linked-release.json'),('post-build-attestation.json','post-build-attestation.json')]:
  require(RELEASE['pins'][name]==evidence[original_name],'WRONG_VERIFICATION_RECEIPT_HASH')
 require(attestation['kind']=='POST_BUILD_VERIFICATION_ATTESTATION' and attestation['original_report_sha256']==final['original_report_sha256']==RELEASE['pins']['original-build-report.json'],'WRONG_ATTESTATION_PROVENANCE')
 require(final['original_failure_receipt_sha256']==RELEASE['pins']['original-target-failure.json'],'WRONG_ORIGINAL_FAILURE')
 adapter=attestation['usb_observer_target_adapter']
 require(adapter['source_commit']==SOURCE and adapter['build_inputs_sha256']==digest(inputs) and adapter['overlay_calls']==1 and adapter['source_commit_contains_changes'] is True and adapter['clean_compile'] is True,'WRONG_AUDITED_BUILD_PROVENANCE')
 gate=linked['usb_observer_release_verification']
 require(target==adapter['usb_observer_target_binding']==gate['usb_observer_target_binding'] and target['status']==gate['status']==linked['status']=='PASS','WRONG_TARGET_BINDING')
 require(gate['full_frozen_h1_chain_executed'] is True and gate['assertions_preserved']==190 and gate['assertions_removed']==0 and len(gate['compile_events'])==6,'INCOMPLETE_FROZEN_CHAIN')
 require(linked['admission_diagnostics_release_verification']['status']=='PASS','INCOMPLETE_OUTER_RELEASE')
 require(original['report']['application_sha256']==target['application_sha256']==APP_SHA and original['report']['application_bytes']==APP_BYTES,'WRONG_APPLICATION_BINDING')
 require(original['provenance']['elf_sha256']==target['elf_sha256']==RELEASE['elf_sha256'] and target['map_sha256']==RELEASE['map_sha256'],'WRONG_LINK_BINDING')
 require(final['historical_del']==m.get('historical_gate')=='BLOCKED / EXACT HISTORICAL INPUT UNAVAILABLE','WRONG_HISTORICAL_GATE')
 require(final['firmware_compilations_total']==final['auxiliary_compilations_total']==1 and final['verified_original_build_files']==771,'WRONG_BUILD_HISTORY')
 require(m.get('runtime_peak_stack_measured') is False,'WRONG_STACK_CLAIM')
 prior=m['prior_define_statements_return']
 require(prior['role']=='PRIOR_OWNER_REPORTED_INSTALLED_BUILD_REFERENCE','WRONG_PRIOR_RETURN_ROLE')
 image(read(d/prior['file'],1451184),1451184,'524805fbde1af49b908b156e0eb50de48393b8e2810efcf0eaddba931408012e')


def validate(directory,installed_table=None,installed_ota=None,require_installed=False,selected="application"):
 require(RELEASE is not None,'RELEASE_NOT_BOUND')
 require(selected in ("application","rollback"),"UNKNOWN_IMAGE_SELECTION")
 d=pathlib.Path(directory);m=json.loads(read(d/'manifest.json',1024*1024));require(m.get('package_id')=='evilduck-routeb-combined-h1-v1-macos-owner-review' and m.get('source_commit')==SOURCE and m.get('installation_authorized') is False and m.get('update_method')=='FUTURE_ROM_APP_ONLY_BOTH_SLOTS','WRONG_PACKAGE_IDENTITY')
 require(m.get('application_bytes')==APP_BYTES and m.get('application_sha256')==APP_SHA and m.get('table_sha256')==TABLE_SHA,'WRONG_DECLARED_ARTIFACT_IDENTITY')
 check_rows(m['proposed_writes']);check_rows(m['rollback_writes'],'rollback');require(m.get('rollback_bytes')==ROLLBACK_BYTES and m.get('rollback_sha256')==ROLLBACK_SHA,'WRONG_ROLLBACK_IDENTITY');require(set(m['support_files'])==SUPPORT,'WRONG_SUPPORT_INVENTORY')
 expected=SUPPORT|{'manifest.json','application.bin','expected-partitions.bin','rollback-application.bin'}
 require({p.name for p in d.iterdir()}==expected and all(p.is_file() and not p.is_symlink() for p in d.iterdir()),'UNEXPECTED_PACKAGE_CONTENT')
 for n,r in m['support_files'].items():
  b=read(d/n,4*1024*1024);require(len(b)==r['bytes'] and digest(b)==r['sha256'],'SUPPORT_INTEGRITY_FAILED')
 image(read(d/'application.bin',APP_BYTES));image(read(d/'rollback-application.bin',ROLLBACK_BYTES),ROLLBACK_BYTES,ROLLBACK_SHA)
 spec=importlib.util.spec_from_file_location('pinned_partition_tool',d/'gen_esp32part.py');tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool);tool.offset_part_table=0x8000
 table(read(d/'expected-partitions.bin',4096),tool)
 validate_evidence(d,m)
 # Working return is an exact original reviewed kit, not a relabelled old rollback.
 require(m.get('working_firmware_return')==WORKING_RETURN,'WRONG_WORKING_RETURN_IDENTITY')
 working=read(d/WORKING_ZIP_FILE,WORKING_ZIP_BYTES)
 require(len(working)==WORKING_ZIP_BYTES and digest(working)==WORKING_ZIP_SHA,'WRONG_WORKING_RETURN_ZIP')
 with zipfile.ZipFile(io.BytesIO(working)) as return_zip:
  require(return_zip.testzip() is None and len(return_zip.infolist())==50,'INVALID_WORKING_RETURN_ARCHIVE')
  for item in return_zip.infolist():
   selected_path=pathlib.PurePosixPath(item.filename)
   require(not selected_path.is_absolute() and '..' not in selected_path.parts and not stat.S_ISLNK(item.external_attr>>16),'UNSAFE_WORKING_RETURN_ARCHIVE')
  return_manifest=json.loads(return_zip.read('manifest.json'))
  require(return_manifest.get('firmware_build_id')=='ROUTEB-DEFINE-LABELS-H1-v1','WRONG_WORKING_RETURN_BUILD_ID')
  working_app=return_zip.read('application.bin');working_rollback=return_zip.read('rollback-application.bin')
  require(len(working_app)==WORKING_APP_BYTES and digest(working_app)==WORKING_APP_SHA,'WRONG_WORKING_RETURN_APPLICATION')
  require(len(working_rollback)==ROLLBACK_BYTES and digest(working_rollback)==ROLLBACK_SHA,'WRONG_WORKING_RETURN_OLDER_ROLLBACK')
  for name in ['preflight.py','installer.py','install-macos.sh','rollback-macos.sh','INSTALL-MAC.md']:
   contents=return_zip.read(name);declared=return_manifest['support_files'][name]
   require(len(contents)==declared['bytes'] and digest(contents)==declared['sha256'],'WRONG_WORKING_RETURN_HELPER')
 rollback_receipt=json.loads(read(d/'rollback-build-receipt.json',4*1024*1024));require(rollback_receipt['report']['application_sha256']==ROLLBACK_SHA and rollback_receipt['report']['application_bytes']==ROLLBACK_BYTES,'WRONG_ROLLBACK_RECEIPT')
 out=dict(selected_image=selected,plan_ready=False,package_integrity='PASS',source_commit=SOURCE,application_sha256=APP_SHA,installed_metadata='NOT_SUPPLIED',selected_write_ranges=[],installation_authorized=False,hardware_access=False,device_authenticity_or_freshness_verified=False)
 require(not require_installed or (installed_table is not None and installed_ota is not None),'CURRENT_INSTALLED_METADATA_REQUIRED')
 require((installed_table is None)==(installed_ota is None),'BOTH_INSTALLED_METADATA_FILES_REQUIRED')
 if installed_table is not None:
  table(read(installed_table,4096),tool);ota(read(installed_ota,8192));out.update(installed_metadata='SUPPLIED_FILES_MATCH_SUPPORTED_LAYOUT_AND_APP0_INITIALIZER',plan_ready=True,selected_write_ranges=rows(selected),boot_selection_from_supplied_metadata='app0',metadata_provenance='OWNER_LOCAL_FILES_NOT_AUTHENTICATED_DEVICE_READ')
 return out
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',type=pathlib.Path,required=True);p.add_argument('--installed-table',type=pathlib.Path);p.add_argument('--installed-otadata',type=pathlib.Path);p.add_argument("--require-installed",action="store_true");p.add_argument("--image",choices=["application","rollback"],default="application");a=p.parse_args()
 try:print(json.dumps(validate(a.directory,a.installed_table,a.installed_otadata,a.require_installed,a.image),indent=2));return 0
 except (OSError,ValueError,KeyError,AssertionError) as e:
  print(json.dumps(dict(package_integrity='REJECTED',reason=str(e) if isinstance(e,Rejected) else 'INVALID_OR_MISSING_INPUT',installation_authorized=False,hardware_access=False)));return 1
if __name__=='__main__':raise SystemExit(main())
