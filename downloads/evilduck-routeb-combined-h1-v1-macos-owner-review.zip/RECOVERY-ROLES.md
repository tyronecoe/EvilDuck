# Recovery artifacts

- `prior-define-statements-application.bin` is the preserved application of
  ROUTEB-DEFINE-STATEMENTS-H1-v1, the latest owner-reported installed build.
  Its original guarded kit identity appears in manifest.json. This copy is an
  evidence and return reference.
- `working-define-labels-macos-review-v1.zip` is the byte-identical guarded
  ROUTEB-DEFINE-LABELS-H1-v1 working-return kit.
- `rollback-application.bin` is the older source/text-v2 recovery image.
  Its original build receipt is included. The inherited rollback helper
  refers to this role.

The current kit is for offline review. Recovery requires separate owner
authorization and review of the selected kit and current device state.
