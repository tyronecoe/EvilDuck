# ROUTEB-COMBINED-H1-v1 Mac owner review

Local review candidate for Intel macOS High Sierra 10.13.6 with Bash 3.2 and
Python 3.8 or newer. Keep the board disconnected. From a fresh extraction run
`python3 preflight.py --directory .`. Expect integrity PASS, installation
authorization false, an empty selected write range list, and hardware access
false. The guarded installer is unbound for this kit. Offline verification
ran in the build workspace. Actual High Sierra execution is pending.

## Release notes

- A standalone DEFINE label can expand to exact `STOP_PAYLOAD`. It cancels the
  request using the literal STOP path and clears held keys.
- A standalone DEFINE label can expand to exact `RESET`. It clears held keys
  and continues the same request. Both aliases reject replacement arguments.
- Left-shift counts 0 through 15 retain the low 16 bits. For example,
  `65535 << 1` now gives `0xFFFE` where it previously raised `Arithmetic`.
  Counts 16 and above still raise `Arithmetic`.

Firmware source is `c2b6fa35d6a50609bd9b4c59409e1aa2f1b417e8`. The executed
verifier repair is `08227890083e654e803d61d416672042c55a6539`. The included
final receipt and post-build attestation record the passing target and
release gates on the preserved image. Historical DEL remains BLOCKED /
EXACT HISTORICAL INPUT UNAVAILABLE. See OWNER-CHECK.md and RECOVERY-ROLES.md.
