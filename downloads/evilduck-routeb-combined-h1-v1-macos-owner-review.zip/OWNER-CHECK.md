# Owner checks pending separate installation authorization

Use a blank editor for the later checks and confirm the displayed build ID
is ROUTEB-COMBINED-H1-v1. Record request state and exact visible output.

- STOP alias. Define `DEFINE #HALT STOP_PAYLOAD`, then run `HOLD SHIFT`,
  `#HALT`, and `STRING unexpected` on separate lines. Expect cancellation,
  held Shift cleared, and no marker. Immediately run a separate harmless
  lowercase text request to check recovery.
- RESET alias. Define `DEFINE #CLEAR_KEYS RESET`, then run `HOLD SHIFT`,
  `#CLEAR_KEYS`, and `STRING a` on separate lines. Expect a single lowercase
  `a` and completion in the same request.
- Left shift. Evaluate `VAR $x = (65535 << 1)`. In the same harmless script,
  conditionally print `shift_ok` only if `$x == 0xFFFE`. Expect the marker
  once and completion. Use a separate script with `VAR $x = (1 << 16)` to
  confirm rejection with Arithmetic and no typed output.
