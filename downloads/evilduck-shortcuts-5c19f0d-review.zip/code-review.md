# EvilDuck Route B keyboard-shortcut review

Reviewed October 16, 2026, America/Vancouver.

Commit: [5c19f0dacb25960bda36a97f4ff871937a3cc9e7](https://github.com/tyronecoe/EvilDuck/commit/5c19f0dacb25960bda36a97f4ff871937a3cc9e7), parent `6280b1d7b465f5d29800fa230ab60f3b04bf77c4`.

## Findings and decision

No blocking correctness defect was identified in the inspected transient-shortcut changes. The candidate is suitable to advance to installation-package preparation. This is a scoped code review, not proof of physical modifier release or authorization to install an image.

The public report correctly distinguishes new-candidate software evidence from the earlier Stage28X hardware results. Existing X hardware passes do not validate the changed application. The old X/Y download remains a rollback reference, not the new install package.

## What was checked

- Read the complete shortcut patch, new application/bridge/compiler test cases, source manifest, test runner logic, builder, reproduction instructions, reported limitations and machine-readable result/build receipts.
- Verified that source modifiers survive compiler IR into the runtime Event; the actual adapter forwards the mask into the existing guarded scheduler API. Retry comparison includes modifier bits as well as event type and value. No raw report submission was added to the parser.
- Checked fixed US character mapping, implicit Shift merging, the F12/F13 usage discontinuity, canonical left modifier aliases, duplicate-modifier rejection, bounded final-operand DEFINE expansion, new reserved function names and inactive-code preflight.
- Checked that persistent HOLD/RELEASE remains rejected by the actual adapter and that INJECT_MOD/RESET remain outside the candidate capability. The mock Bridge's broader API does not override that production gate.
- Inspected tests for press/restoration report bytes, backpressure, STOP, runtime errors, cancellation before/during a chord, disconnect and ambiguous acceptance. These are mocked local-submission tests, not host-delivery evidence.
- Matched all nine patched-source hashes in the target receipt to the committed source manifest. The receipt contains the four-argument `route_b::key` symbol, the explicit shortcut/Route B/diagnostic selectors and the protected HID/NVS flags.

## Independent verification performed in this review

The relevant immutable base source was obtained and checked against the candidate's pre-patch SHA-256 pins. The focused patch was applied with zero fuzz. The resulting core, keyboard, bridge and new shared header matched the committed post-patch hashes.

The following exact committed test cases were then compiled and run locally:

| Scope | Cases | Assertions | Result |
| --- | ---: | ---: | --- |
| Bridge/Planner | B01–B08 (8) | 166 | PASS |
| Compiler/runtime | C01–C03 (3) | 126 | PASS |
| Independently reproduced total | 11 | 292 | PASS |

These runs used AddressSanitizer and UndefinedBehaviorSanitizer with halt-on-error. No ASan/UBSan findings were reported in the completed runs. LeakSanitizer failed to initialize/inspect process-task information under this execution environment. The initial environment failures were retained, and the same cases were rerun with leak detection disabled. This review therefore does not independently confirm the published leak-check result.

The 202 PASS / 398,016 assertion aggregate was independently recomputed from the published per-case receipt and matches the report. It was not fully re-executed here. The actual application K01–K25 cases were inspected, not rerun in this review. No new ESP32 target rebuild, physical board access, serial operation or HID output occurred here.

## T34 and other coverage qualifications

The unchanged T34 test creates a Linux thread but does not assign a different simulated RTOS task. In the inspected V task mock, each thread defaults to task 1. Its foreign-owner expectation therefore does not model a different RTOS owner under that composition. The separate failed observation is disclosed in the receipt and excluded from the final PASS count.

K25 explicitly assigns task 2 and checks that it cannot borrow the active task-1 backend scope or send a report, after which task 1 completes. This supports the stated explanation of T34; it is not a new reproduction of that application test by this review. Keeping the historical test unchanged and its exception visible is appropriate.

Five old core groups are explicitly excluded for changed vocabulary assumptions. New C01/C02 reproduce selected capacity and reservation checks using non-colliding function names. This is a selected regression set, not a claim that every historical assertion was preserved or rerun.

## Candidate identity

The inspected target build receipt reports:

- Application: 1,359,808 bytes, SHA-256 `de241287b972c24e510d3e8d22d888a17f13d1e972142559ba3df19f6195b41d`.
- ELF SHA-256: `fe5569b0a6d1819e266c7db3b16f7232929e87051123d7e0a4448fb57cb2f376`.
- Static RAM: 106,264 bytes; application growth 1,584 bytes and static RAM growth 8 bytes against installed X.
- Partition-table SHA-256: `b79bde9ef4a9544411d97a31a1d326b2028213269ad0dcc643ea921230ce3d5e`, unchanged according to the reviewed report/receipt.
- Bootloader SHA-256: `95b966ad240a05bf8a804cd4519eebac5271b662e51417668da488652b7354bf`, likewise unchanged.

These are checked receipt identities, not hashes computed from a downloaded candidate BIN/ELF in this review. Startup banners alone are insufficient to distinguish the candidate from X. A package must bind the changed application bytes to this commit and its build receipt.

## Concrete next step

Prepare a new downloadable candidate package in the environment that holds the built artifacts. Include the exact application BIN, a file/range manifest with SHA-256s, source/build identity, installation preflight, the existing rollback package reference and the reviewed editor-only fixture. Preserve the original backup and private settings.

The package should specify the intended update method and verify the installed layout/active-slot assumptions before selecting write ranges. The unchanged table does not justify blindly using the link-time address as an update target. Do not reuse the old X manifest with the new application substituted under its old identity, and do not introduce a partition migration or data erase without a demonstrated need.

After a concrete package is available for review, installation and the small physical trial can be considered. The proposed fixture's intended text is:

```text
abZ
done
```

It uses COMMAND a to select existing contents and SHIFT LEFTARROW to select one character, so its target must be a new, empty, disposable editor document. Use explicit Route B selection, review capitalization/substitution settings, verify fixture bytes and run once. A device counter acknowledging local cleanup remains distinct from what the Mac actually received.

This review prepared no install package, changed no remote refs, and did not flash or modify the installed firmware.

## Reviewed repository references

- [Implementation report](https://github.com/tyronecoe/EvilDuck/blob/5c19f0dacb25960bda36a97f4ff871937a3cc9e7/docs/keyboard-shortcuts-report.md)
- [Source patch](https://github.com/tyronecoe/EvilDuck/blob/5c19f0dacb25960bda36a97f4ff871937a3cc9e7/tests/keyboard_shortcuts/shortcuts.patch)
- [Source manifest](https://github.com/tyronecoe/EvilDuck/blob/5c19f0dacb25960bda36a97f4ff871937a3cc9e7/docs/keyboard-shortcuts-source-manifest.json)
- [Test receipt](https://github.com/tyronecoe/EvilDuck/blob/5c19f0dacb25960bda36a97f4ff871937a3cc9e7/docs/keyboard-shortcuts-results.json)
- [Build receipt](https://github.com/tyronecoe/EvilDuck/blob/5c19f0dacb25960bda36a97f4ff871937a3cc9e7/docs/keyboard-shortcuts-build.json)
- [Owner trial document](https://github.com/tyronecoe/EvilDuck/blob/5c19f0dacb25960bda36a97f4ff871937a3cc9e7/docs/keyboard-shortcuts-owner-review.md)
