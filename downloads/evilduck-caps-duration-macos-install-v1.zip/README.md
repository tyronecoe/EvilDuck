Read INSTALL-MAC.md first. ROLLBACK-MAC.md returns to the owner-installed 2c657f0c application (installation receipt and observed buildId; not a new readback).
Software/package review only; no physical installation authorization. Caps Lock and LED feedback remain physically unverified.
