Read INSTALL-MAC.md first. ROLLBACK-MAC.md returns to the owner-tested 58b0fb93 application (installation receipt and observed buildId; not a new readback).
Software/package review only; no physical installation authorization. Prior 500ms diagnostic Caps/feedback is owner-confirmed. New ordinary timing setting remains physically unverified.
