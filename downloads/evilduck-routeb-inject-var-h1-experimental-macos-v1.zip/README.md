EXPERIMENTAL — REVIEW ONLY — NOT AUTHORIZED FOR FLASHING
Route B INJECT_VAR H1 app-only High Sierra package. Read INSTALL-MAC.md and OWNER-CHECK.md. H1 is an EvilDuck hypothesis, not verified Hak5 runtime encoding. Physical H1 and inherited configurable lock-wait acceptance remain pending. No install, boot or test is authorized by downloading this package. Exact accepted source/text v2 rollback: cf42dea0570dcf491c46677aa87dd28bd6347f1617b0eea73ac670b52ba81f02.
First offline check: python3 preflight.py --directory .
